package com.example.data.weather

import kotlin.math.roundToInt

data class DistrictWeather(
    val districtName: String,
    val province: String,
    val temperatureCelsius: Float,
    val relativeHumidityPercent: Float,
    val windSpeedKmh: Float,
    val condition: String, // Sunny, Hot & Humid, Rain Showers, Dusty wind
    val rainProbabilityPercent: Int,
    val outbreaksPredicted: List<DiseasePrediction>
)

data class DiseasePrediction(
    val diseaseName: String,
    val riskLevel: String, // Low, Moderate, High, Severe
    val description: String,
    val recommendedAction: String
)

data class ClinicItem(
    val name: String,
    val location: String,
    val phone: String,
    val specialty: String
)

data class FodderItem(
    val name: String,
    val type: String,
    val suitability: String,
    val feedingInterval: String,
    val description: String,
    val benefits: String
)

object WeatherRiskManager {

    data class Coordinates(val lat: Double, val lon: Double)

    val districtCoordinates = mapOf(
        "multan" to Coordinates(30.1575, 71.5249),
        "sahiwal" to Coordinates(30.6682, 73.1114),
        "sargodha" to Coordinates(32.0836, 72.6711),
        "faisalabad" to Coordinates(31.4504, 73.1350),
        "sibi" to Coordinates(29.5448, 67.8764),
        "quetta" to Coordinates(30.1798, 66.9750),
        "peshawar" to Coordinates(34.0151, 71.5249),
        "hyderabad" to Coordinates(25.3960, 68.3578),
        "bahawalpur" to Coordinates(29.3544, 71.6911),
        "sialkot" to Coordinates(32.4945, 74.5229),
        "lahore" to Coordinates(31.5204, 74.3587),
        "karachi" to Coordinates(24.8607, 67.0011),
        "rawalpindi" to Coordinates(33.5651, 73.0169),
        "islamabad" to Coordinates(33.6844, 73.0479),
        "swat" to Coordinates(35.2227, 72.4258),
        "muzaffarabad" to Coordinates(34.3700, 73.4711),
        "gwadar" to Coordinates(25.1216, 62.3254),
        "dera ghazi khan" to Coordinates(30.0344, 70.6394),
        "deraghazikhan" to Coordinates(30.0344, 70.6394),
        "mianwali" to Coordinates(32.5741, 71.5264),
        "tharparkar" to Coordinates(24.7411, 69.8011)
    )

    val availableDistricts = listOf(
        "Multan", "Sahiwal", "Sargodha", "Faisalabad", "Sibi", "Quetta", "Peshawar", "Hyderabad", "Bahawalpur", "Sialkot",
        "Lahore", "Karachi", "Rawalpindi", "Islamabad", "Swat", "Muzaffarabad", "Gwadar", "Dera Ghazi Khan", "Mianwali", "Tharparkar"
    )

    fun getWeatherForDistrict(districtName: String): DistrictWeather {
        return when (districtName.lowercase().trim()) {
            "multan" -> DistrictWeather(
                districtName = "Multan",
                province = "Punjab",
                temperatureCelsius = 39f,
                relativeHumidityPercent = 64f,
                windSpeedKmh = 12f,
                condition = "Hot & Humid",
                rainProbabilityPercent = 25,
                outbreaksPredicted = listOf(
                    DiseasePrediction(
                        diseaseName = "Bluetongue (BT)",
                        riskLevel = "High",
                        description = "High humidity and temperatures of 39°C fuel Culicoides vector breeding.",
                        recommendedAction = "Apply insecticide/repellents on sheep/goats, move herd to dry shaded areas."
                    ),
                    DiseasePrediction(
                        diseaseName = "Foot and Mouth Disease (FMD)",
                        riskLevel = "Moderate",
                        description = "Standard risk parameters for mixed dairy hubs in Multan Division.",
                        recommendedAction = "Sanitize feeding troughs, isolate returning or newly bought cows."
                    )
                )
            )
            "sahiwal" -> DistrictWeather(
                districtName = "Sahiwal",
                province = "Punjab",
                temperatureCelsius = 37f,
                relativeHumidityPercent = 70f,
                windSpeedKmh = 10f,
                condition = "Humid Clover-lands",
                rainProbabilityPercent = 35,
                outbreaksPredicted = listOf(
                    DiseasePrediction(
                        diseaseName = "Bluetongue (BT)",
                        riskLevel = "Severe",
                        description = "Excessive moisture (70% RH) near Ravi canal basins is highly favorable for midge swarms.",
                        recommendedAction = "Strict evening vector control near barns. Avoid pooling water near livestock."
                    ),
                    DiseasePrediction(
                        diseaseName = "Hemorrhagic Septicemia (HS)",
                        riskLevel = "High",
                        description = "Highly prevalent in damp soil for local buffaloes.",
                        recommendedAction = "Verify immediate HS vaccine booster for Sahiwal pedigree cattle herds."
                    )
                )
            )
            "sargodha" -> DistrictWeather(
                districtName = "Sargodha",
                province = "Punjab",
                temperatureCelsius = 36f,
                relativeHumidityPercent = 55f,
                windSpeedKmh = 15f,
                condition = "Dry Breezy",
                rainProbabilityPercent = 10,
                outbreaksPredicted = listOf(
                    DiseasePrediction(
                        diseaseName = "Peste des Petits Ruminants (PPR)",
                        riskLevel = "High",
                        description = "Breezy conditions favor viral transport in small ruminant populations.",
                        recommendedAction = "Perform ring vaccination of Kajli sheep and Beetal goats."
                    ),
                    DiseasePrediction(
                        diseaseName = "Bluetongue (BT)",
                        riskLevel = "Moderate",
                        description = "Moderate vector population due to dry night winds.",
                        recommendedAction = "Incorporate vector traps in outdoor enclosures."
                    )
                )
            )
            "faisalabad" -> DistrictWeather(
                districtName = "Faisalabad",
                province = "Punjab",
                temperatureCelsius = 38f,
                relativeHumidityPercent = 48f,
                windSpeedKmh = 14f,
                condition = "Sunny & Warm",
                rainProbabilityPercent = 15,
                outbreaksPredicted = listOf(
                    DiseasePrediction(
                        diseaseName = "Foot & Mouth Disease (FMD)",
                        riskLevel = "High",
                        description = "High movement of cattle across marketing routes.",
                        recommendedAction = "Restrict transport of young calves, apply limewash disinfection."
                    )
                )
            )
            "sibi" -> DistrictWeather(
                districtName = "Sibi",
                province = "Balochistan",
                temperatureCelsius = 44f,
                relativeHumidityPercent = 28f,
                windSpeedKmh = 22f,
                condition = "Extreme Heat Stress",
                rainProbabilityPercent = 5,
                outbreaksPredicted = listOf(
                    DiseasePrediction(
                        diseaseName = "Heat Exhaustion / Thermal Stress",
                        riskLevel = "Severe",
                        description = "THI surpasses critical limit of 88, severe threat of milk drop.",
                        recommendedAction = "Provide constant cool drinking water, activate rooftop misting fans."
                    )
                )
            )
            "quetta" -> DistrictWeather(
                districtName = "Quetta",
                province = "Balochistan",
                temperatureCelsius = 28f,
                relativeHumidityPercent = 30f,
                windSpeedKmh = 18f,
                condition = "Pleasant Highlands",
                rainProbabilityPercent = 10,
                outbreaksPredicted = listOf(
                    DiseasePrediction(
                        diseaseName = "Peste des Petits Ruminants (PPR)",
                        riskLevel = "Moderate",
                        description = "Dry highland air can irritate upper respiratory zones in goats.",
                        recommendedAction = "Ensure healthy ventilation in closed mountain pens."
                    )
                )
            )
            "peshawar" -> DistrictWeather(
                districtName = "Peshawar",
                province = "Khyber Pakhtunkhwa",
                temperatureCelsius = 34f,
                relativeHumidityPercent = 60f,
                windSpeedKmh = 11f,
                condition = "Scattered Clouds",
                rainProbabilityPercent = 40,
                outbreaksPredicted = listOf(
                    DiseasePrediction(
                        diseaseName = "Black Quarter (BQ)",
                        riskLevel = "High",
                        description = "Soil disturbance from rain releases dormant spores.",
                        recommendedAction = "Vaccinate cattle against Chauvoei spores before rain season."
                    )
                )
            )
            "hyderabad" -> DistrictWeather(
                districtName = "Hyderabad",
                province = "Sindh",
                temperatureCelsius = 38f,
                relativeHumidityPercent = 68f,
                windSpeedKmh = 16f,
                condition = "Humid Coastal Winds",
                rainProbabilityPercent = 30,
                outbreaksPredicted = listOf(
                    DiseasePrediction(
                        diseaseName = "Lumpy Skin Disease (LSD)",
                        riskLevel = "High",
                        description = "Biting flies and mosquitoes active along Indus banks.",
                        recommendedAction = "Isolate animals with visible skin nodules, apply fly traps."
                    )
                )
            )
            "lahore" -> DistrictWeather(
                districtName = "Lahore",
                province = "Punjab",
                temperatureCelsius = 36f,
                relativeHumidityPercent = 65f,
                windSpeedKmh = 10f,
                condition = "Hazy Summer",
                rainProbabilityPercent = 30,
                outbreaksPredicted = listOf(
                    DiseasePrediction(
                        diseaseName = "Foot and Mouth Disease (FMD)",
                        riskLevel = "High",
                        description = "High cattle movement around Lahore peri-urban dairy colonies.",
                        recommendedAction = "Maintain strict biosecurity, disinfect trucks & milking sheds."
                    )
                )
            )
            "karachi" -> DistrictWeather(
                districtName = "Karachi",
                province = "Sindh",
                temperatureCelsius = 34f,
                relativeHumidityPercent = 75f,
                windSpeedKmh = 20f,
                condition = "Marine Breeze",
                rainProbabilityPercent = 15,
                outbreaksPredicted = listOf(
                    DiseasePrediction(
                        diseaseName = "Lumpy Skin Disease (LSD)",
                        riskLevel = "High",
                        description = "High coastal humidity is breeding biting stable flies rapidly.",
                        recommendedAction = "Spray animals with repellents, clear standing water in Cattle Colony."
                    )
                )
            )
            "swat" -> DistrictWeather(
                districtName = "Swat",
                province = "Khyber Pakhtunkhwa",
                temperatureCelsius = 24f,
                relativeHumidityPercent = 45f,
                windSpeedKmh = 12f,
                condition = "Cool Mountain Breeze",
                rainProbabilityPercent = 25,
                outbreaksPredicted = listOf(
                    DiseasePrediction(
                        diseaseName = "Peste des Petits Ruminants (PPR)",
                        riskLevel = "Low",
                        description = "Excellent air circulation, vector burden is very limited.",
                        recommendedAction = "Routine clinical care, focus on lamb vaccination sheets."
                    )
                )
            )
            "muzaffarabad" -> DistrictWeather(
                districtName = "Muzaffarabad",
                province = "Azad Kashmir",
                temperatureCelsius = 26f,
                relativeHumidityPercent = 50f,
                windSpeedKmh = 8f,
                condition = "Valley Clouds",
                rainProbabilityPercent = 45,
                outbreaksPredicted = listOf(
                    DiseasePrediction(
                        diseaseName = "Brucellosis",
                        riskLevel = "Moderate",
                        description = "Moisture allows pasture retention of pathogens.",
                        recommendedAction = "Boil all raw milk, isolate aborting sheep or goats."
                    )
                )
            )
            "gwadar" -> DistrictWeather(
                districtName = "Gwadar",
                province = "Balochistan",
                temperatureCelsius = 32f,
                relativeHumidityPercent = 80f,
                windSpeedKmh = 25f,
                condition = "Coastal Humidity",
                rainProbabilityPercent = 5,
                outbreaksPredicted = listOf(
                    DiseasePrediction(
                        diseaseName = "External Parasites / Ticks",
                        riskLevel = "High",
                        description = "High marine humidity promotes tick reproduction on camels & goats.",
                        recommendedAction = "Weekly anti-tick dip or ivermectin injections."
                    )
                )
            )
            "tharparkar" -> DistrictWeather(
                districtName = "Tharparkar",
                province = "Sindh",
                temperatureCelsius = 42f,
                relativeHumidityPercent = 35f,
                windSpeedKmh = 18f,
                condition = "Arid Drought Stress",
                rainProbabilityPercent = 5,
                outbreaksPredicted = listOf(
                    DiseasePrediction(
                        diseaseName = "Sheep Pox",
                        riskLevel = "Severe",
                        description = "Severe dry drought stress damages respiratory defenses.",
                        recommendedAction = "Provide supplemental vitamin packets, vaccinate sheep urgently."
                    )
                )
            )
            "bahawalpur" -> DistrictWeather(
                districtName = "Bahawalpur",
                province = "Punjab",
                temperatureCelsius = 41f,
                relativeHumidityPercent = 42f,
                windSpeedKmh = 14f,
                condition = "Sandy Desert Heat",
                rainProbabilityPercent = 8,
                outbreaksPredicted = listOf(
                    DiseasePrediction(
                        diseaseName = "Enterotoxemia (ET)",
                        riskLevel = "Moderate",
                        description = "High summer dry feeding blocks increase toxin susceptibility in small ruminants.",
                        recommendedAction = "Coordinate booster vaccinations for all Cholistani sheep herds."
                    )
                )
            )
            "sialkot" -> DistrictWeather(
                districtName = "Sialkot",
                province = "Punjab",
                temperatureCelsius = 33f,
                relativeHumidityPercent = 72f,
                windSpeedKmh = 9f,
                condition = "Humid Broad-basin",
                rainProbabilityPercent = 45,
                outbreaksPredicted = listOf(
                    DiseasePrediction(
                        diseaseName = "Hemorrhagic Septicemia (HS)",
                        riskLevel = "Severe",
                        description = "Canals and high humidity encourage septicemic pasteurella bacteria breeding.",
                        recommendedAction = "Immediate administration of HS vaccine for Sahiwal and Nili-Ravi herds."
                    )
                )
            )
            "rawalpindi" -> DistrictWeather(
                districtName = "Rawalpindi",
                province = "Punjab",
                temperatureCelsius = 31f,
                relativeHumidityPercent = 52f,
                windSpeedKmh = 14f,
                condition = "Sub-Mountain Clouds",
                rainProbabilityPercent = 50,
                outbreaksPredicted = listOf(
                    DiseasePrediction(
                        diseaseName = "Black Quarter (BQ)",
                        riskLevel = "High",
                        description = "Heavy rains stir up Clostridium spores in sub-mountainous soils.",
                        recommendedAction = "Avoid grazing in direct muddy lowlands, keep shelters well-drained."
                    )
                )
            )
            "islamabad" -> DistrictWeather(
                districtName = "Islamabad",
                province = "Punjab/Capital",
                temperatureCelsius = 30f,
                relativeHumidityPercent = 50f,
                windSpeedKmh = 12f,
                condition = "Fresh Margalla Breeze",
                rainProbabilityPercent = 35,
                outbreaksPredicted = listOf(
                    DiseasePrediction(
                        diseaseName = "Peste des Petits Ruminants (PPR)",
                        riskLevel = "Moderate",
                        description = "Normal vector profiles under pleasant temperatures.",
                        recommendedAction = "Ensure small goats are kept dry during unexpected downpours."
                    )
                )
            )
            "dera ghazi khan", "deraghazikhan" -> DistrictWeather(
                districtName = "Dera Ghazi Khan",
                province = "Punjab",
                temperatureCelsius = 40f,
                relativeHumidityPercent = 45f,
                windSpeedKmh = 16f,
                condition = "Arid River Plains",
                rainProbabilityPercent = 10,
                outbreaksPredicted = listOf(
                    DiseasePrediction(
                        diseaseName = "Foot and Mouth Disease (FMD)",
                        riskLevel = "High",
                        description = "Active marketing and transport of Bhagnari bulls increases infection vector speeds.",
                        recommendedAction = "Restrict uncertified mixing at river-basin cattle mandi spots."
                    )
                )
            )
            "mianwali" -> DistrictWeather(
                districtName = "Mianwali",
                province = "Punjab",
                temperatureCelsius = 39f,
                relativeHumidityPercent = 40f,
                windSpeedKmh = 15f,
                condition = "Dry Indochannel Gusts",
                rainProbabilityPercent = 12,
                outbreaksPredicted = listOf(
                    DiseasePrediction(
                        diseaseName = "Contagious Caprine Pleuropneumonia (CCPP)",
                        riskLevel = "High",
                        description = "Dust storms and rapid drying conditions weaken respiratory tract defenses.",
                        recommendedAction = "Equip sheds with windbreaks and provide eucalyptus-infused water misting."
                    )
                )
            )
            else -> DistrictWeather(
                districtName = districtName,
                province = "Pakistan",
                temperatureCelsius = 35f,
                relativeHumidityPercent = 50f,
                windSpeedKmh = 12f,
                condition = "Clear Sky",
                rainProbabilityPercent = 20,
                outbreaksPredicted = listOf(
                    DiseasePrediction(
                        diseaseName = "Bluetongue (BT)",
                        riskLevel = "Moderate",
                        description = "Average seasonal vector load predicted.",
                        recommendedAction = "Routine vaccination, practice general bio-security."
                    )
                )
            )
        }
    }

    // Recommendation rules for breed suitability by area
    // E.g. what breeds are native or recommended for this local area to help with "selective breeds in our area"
    fun getRecommendedBreedsForDistrict(district: String, animalType: String): List<String> {
        val distLower = district.lowercase()
        return when (animalType.trim()) {
            "Cow" -> {
                when {
                    distLower in listOf("multan", "sahiwal", "sargodha", "faisalabad", "bahawalpur", "lahore", "deraghazikhan", "mianwali") ->
                        listOf("Sahiwal Cow", "Cholistani", "Dhanni")
                    distLower in listOf("hyderabad", "karachi", "tharparkar") ->
                        listOf("Red Sindhi", "Tharparkar")
                    distLower in listOf("quetta", "sibi") ->
                        listOf("Bhagnari", "Dhanni", "Sahiwal Cow")
                    else -> // Swat, Peshawar, Gilgit
                        listOf("Achai", "Dhanni")
                }
            }
            "Buffalo" -> {
                when {
                    distLower in listOf("hyderabad", "karachi", "tharparkar") ->
                        listOf("Kundi")
                    distLower in listOf("swat", "peshawar", "gilgit", "muzaffarabad") ->
                        listOf("Azi Kheli", "Nili-Ravi")
                    else ->
                        listOf("Nili-Ravi")
                }
            }
            "Sheep" -> {
                when {
                    distLower in listOf("sargodha", "sahiwal", "multan", "lahore") ->
                        listOf("Kajli Sheep", "Buchi")
                    distLower in listOf("quetta", "sibi", "swat", "peshawar", "gilgit", "muzaffarabad") ->
                        listOf("Balkhi Sheep", "Damani")
                    distLower in listOf("hyderabad", "karachi", "tharparkar") ->
                        listOf("Cholistani Sheep", "Damani")
                    else ->
                        listOf("Damani", "Buchi")
                }
            }
            "Goat" -> {
                when {
                    distLower in listOf("multan", "sahiwal", "sargodha", "faisalabad", "lahore", "mianwali") ->
                        listOf("Beetal Goat", "Teddy Goat", "Dera Din Panah")
                    distLower in listOf("hyderabad", "karachi", "tharparkar") ->
                        listOf("Kamori", "Barbari")
                    distLower in listOf("quetta", "sibi", "swat", "gilgit") ->
                        listOf("Barbari", "Teddy Goat")
                    else ->
                        listOf("Beetal Goat", "Teddy Goat")
                }
            }
            "Bull" -> {
                when {
                    distLower in listOf("quetta", "sibi", "deraghazikhan") ->
                        listOf("Bhagnari Bull", "Sahiwal Bull")
                    distLower in listOf("sargodha", "faisalabad", "mianwali", "rawalpindi") ->
                        listOf("Dhanni Bull", "Sahiwal Bull")
                    else ->
                        listOf("Sahiwal Bull", "Bramfah")
                }
            }
            else -> { // Fat-tailed Sheep / Dumba
                listOf("Dumba (Fat-tailed)")
            }
        }
    }

    // Dynamic clinics by area
    fun getClinicsForDistrict(district: String): List<ClinicItem> {
        val distLower = district.lowercase().trim()
        val baseline = mutableListOf<ClinicItem>()
        
        // Add specific clinics for the selected area
        when {
            distLower == "multan" -> {
                baseline.add(ClinicItem("Punjab Civil Veterinary Hospital", "Kachehri Chowk, Multan", "061-9231011", "Equipped with state-of-the-art diagnostics, bovine artificial insemination."))
                baseline.add(ClinicItem("Fatima Veterinary Clinic", "Chowk Kumharan, Multan", "0300-7301211", "Private companion & herd clinic, dynamic live ultrasound diagnostic center."))
            }
            distLower == "sahiwal" -> {
                baseline.add(ClinicItem("Sahiwal District Ruminant Base", "Civil Lines Road, Sahiwal", "040-9200371", "Specialized Sahiwal pedigree vaccine distribution, Nili-Ravi support."))
                baseline.add(ClinicItem("Livestock Research Institute (LRI)", "Ghas Mandi, Sahiwal", "040-9200234", "High-capacity vaccine supply, milk analysis, and semen banking."))
            }
            distLower == "sargodha" -> {
                baseline.add(ClinicItem("Livestock Research Extension Clinic", "Bypass Road, Sargodha", "048-9230555", "Expert diagnostic tests for Kajli sheep & dairy herds."))
                baseline.add(ClinicItem("Sargodha Civil Animal Clinic", "Mianwali Road, Sargodha", "048-9200122", "Public health center, free lumpy skin vaccine administration."))
            }
            distLower == "faisalabad" -> {
                baseline.add(ClinicItem("UVAS Faisalabad Ruminant HQ", "Jhang Road, Faisalabad", "041-9200161", "Advanced surgical operations, radiology, state-of-the-art foot & mouth treatments."))
                baseline.add(ClinicItem("UAF Veterinary Medical Hospital", "University Road, Faisalabad", "041-9200191", "University-run premier clinical diagnostics, tick eradication kits."))
            }
            distLower == "sibi" -> {
                baseline.add(ClinicItem("Balochistan Rural Livestock Base", "Sibi Cantonment, Sibi", "0833-920114", "Dumba (Fat-tailed) hydration packs, sheep pox vaccines, tick spray base."))
                baseline.add(ClinicItem("Sibi Veterinary Center (Govt)", "Lari Adda Road, Sibi", "0833-920211", "Bulin & camel heat management support, oral rehydration packs."))
            }
            distLower == "quetta" -> {
                baseline.add(ClinicItem("Quetta Cantonment Animal Hospital", "Staff College Road, Quetta", "081-9201144", "Highland PPR vaccination, anti-parasitic distribution, mountain sheep labs."))
                baseline.add(ClinicItem("Balochistan Veterinary Research Institute", "Brewery Road, Quetta", "081-9211333", "Diagnostic laboratory specializing in sheep-pox and vector-borne surveillance."))
            }
            distLower == "peshawar" -> {
                baseline.add(ClinicItem("KP Provincial Veterinary HQ Hospital", "Shami Road, Peshawar", "091-9210271", "Large ruminant emergency trauma care, black quarter treatments."))
                baseline.add(ClinicItem("Khyber Veterinary Clinic", "Ring Road, Peshawar", "0333-9112245", "Private round-the-clock livestock consulting, portable ultrasound service."))
            }
            distLower == "hyderabad" -> {
                baseline.add(ClinicItem("Sindh Veterinary Hospital Hyderabad", "Unit 6, Latifabad, Hyderabad", "022-9210144", "Lumpy skin containment HQ, dairy buffalo saline booster distribution."))
                baseline.add(ClinicItem("Sindh Agriculture Univ Clinic", "Tando Jam, Hyderabad", "022-2765387", "Academically backed disease treatment units, mastitis screening."))
            }
            distLower == "lahore" -> {
                baseline.add(ClinicItem("UVAS Veterinary Hospital Lahore", "Outfall Road, Lahore", "042-99211449", "Premier multi-specialty trauma, surgery, ultrasound, and emergency ICU."))
                baseline.add(ClinicItem("Lahore Cattle Colony civil dispensary", "Raiwind Road, Lahore", "042-35311222", "Mass-scale Foot and Mouth immunization, bovine clinical assistance."))
            }
            distLower == "karachi" -> {
                baseline.add(ClinicItem("Karachi Bhains Colony Civil Clinic", "Road 4, Bhains Colony, Karachi", "021-35012322", "High-volume dairy buffalo emergency therapy, milk loss restoration."))
                baseline.add(ClinicItem("Richmond Crawford Veterinary Hospital", "M.A. Jinnah Road, Karachi", "021-99215031", "Oldest public veterinary hospital in Sindh, rabies & vector therapy.") )
            }
            distLower == "swat" -> {
                baseline.add(ClinicItem("Highland Swat Ruminant Base", "Mingora Bazar, Swat", "0946-9240034", "PPR clinical assistance, anti-parasitic, sheep & goat health support."))
            }
            distLower == "muzaffarabad" -> {
                baseline.add(ClinicItem("AJK Animal Health Center Office", "Sectt Road, Muzaffarabad", "05822-921221", "Brucellosis screening, high-altitude sheep ticks, public health units."))
            }
            distLower == "gwadar" -> {
                baseline.add(ClinicItem("Gwadar Coastal District Clinic", "Airport Road, Gwadar", "086-9210113", "Salt-tolerance nutrition profiles, camel health checkups, tick sprays."))
            }
            distLower == "tharparkar" -> {
                baseline.add(ClinicItem("Tharparkar Govt Ruminant Aid Station", "Mithi Center, Tharparkar", "0232-920045", "Drought nutrition kits, animal dehydration saline, emergency sheep pox aid."))
            }
            else -> {
                baseline.add(ClinicItem("District Civil Animal Hospital", "$district Main Chowk", "051-111222", "Local government clinical center, standard vaccines & disease scanning."))
                baseline.add(ClinicItem("Union Council Mobile Livestock Dispensing", "$district Area Dispatch", "051-333444", "Mobile veterinary technician dispatch, basic temperature & injection support."))
            }
        }
        return baseline
    }

    // Extended feed assets for Pakistani farmers to satisfy "add more feed options"
    fun getExtendedFodderOptions(): List<FodderItem> {
        return listOf(
            FodderItem(
                name = "Barseem Clover (برسیم)",
                type = "Green Fodder (High Protein)",
                suitability = "Optimal for Sheep, Goats, Milking Cows, Buffaloes.",
                feedingInterval = "Daily ration, twice/day during colder or wet months.",
                description = "Grown heavily in canal zones of Punjab and Sindh. Provides highly digestible protein and calcium to support rich milk fat percentages.",
                benefits = "Boosts milk quantity by 10-15%, highly savory."
            ),
            FodderItem(
                name = "Wheat Straw (بکھی یا بھوسہ / توڑی)",
                type = "Dry Roughage",
                suitability = "Cows, Buffaloes, Bulls, Fat-tailed Sheep (Dumba).",
                feedingInterval = "Base roughage, mixed with green clover or silage.",
                description = "The staple dry fodder of Pakistan, stored during wheat harvest seasons. High in lignin. Needs enrichment with urea-molasses or cottonseed cakes.",
                benefits = "Maintains key rumen volume, perfect chewing fiber."
            ),
            FodderItem(
                name = "Rhodes Grass (روڈز گراس)",
                type = "Cultivated Forage (Medium Protein)",
                suitability = "All Cattle, Goats, Dairy Buffaloes, Horses.",
                feedingInterval = "Perfect daily dry/bale feeding during hotter periods.",
                description = "Highly drought resistant grass cultivated extensively under modern pivot irrigation in Punjab. High in dry matter and structural fiber.",
                benefits = "Improves digestion consistency, prevents loose manure."
            ),
            FodderItem(
                name = "Alfalfa / Lucerne (لوسرن)",
                type = "Legume Fodder (Premium Protein)",
                suitability = "Young Calves, Milking Cows, Pregnant Ewes/Goats.",
                feedingInterval = "Incorportated as 20-30% of daily ration for massive growth.",
                description = "The 'Queen of Forages' grown across Balochistan and irrigated Punjab. Rich in protein (18-22%), vitamins, and bone-building Calcium.",
                benefits = "Extremely rapid weight gain, superb milk volume boosts."
            ),
            FodderItem(
                name = "Corn Silage (سائلج)",
                type = "Fermented High-Energy Feed",
                suitability = "High-yielding Dairy Buffaloes, crossbred Holstein Friesian Cows.",
                feedingInterval = "Fed once or twice daily, year-round.",
                description = "Fermented whole-crop maize chopped and packed tightly in pit bunkers. Extremely standard across modern commercial Pakistan dairy hubs.",
                benefits = "Dramatically ensures stable livestock energy intake in dry seasons."
            ),
            FodderItem(
                name = "Cottonseed Cake / Khal (کھل)",
                type = "Protein Concentrate",
                suitability = "Buffaloes, Cows, Fat-tailed Sheep (Dumba).",
                feedingInterval = "Pre-milking feed or winter protein supplement.",
                description = "Derived after crushing cottonseeds in Multan, Bahawalpur, and Sahiwal ginning yards. Adds massive fat contents to buffalo milk.",
                benefits = "Massive milk butterfat % increases. Excellent for fattening Dumba."
            ),
            FodderItem(
                name = "Wheat Bran / Choker (چوکر)",
                type = "Highly Digestible Fiber Feed",
                suitability = "Dairy Cows, Pregnant Buffs, Nursing Goats.",
                feedingInterval = "Daily concentrate mix, dampened with water.",
                description = "The external shell of wheat processed in flour mills of Pakistan. Extremely palatable, high in Phosphorus, acts as a gentle laxative.",
                benefits = "Assists lactation onset, maintains rumen health."
            ),
            FodderItem(
                name = "Urea Molasses Block (شیرہ یو ٹی ایم بلاک)",
                type = "Multi-Nutrient Block Lick",
                suitability = "Adult Cows, Buffaloes, Bulls on dry rations.",
                feedingInterval = "Always place in hanger in barn for self-licking.",
                description = "Licking blocks composed of molasses, urea, minerals, and binding binder. Perfect for rumen microflora energy matching during straw-only feeding.",
                benefits = "Allows rumen microbes to digest rough wheat straw much faster."
            ),
            FodderItem(
                name = "Jowar / Sorghum (جوار)",
                type = "Summer Green Crop",
                suitability = "Cows, Buffaloes, Bulls, Goats.",
                feedingInterval = "Daily cut, during hot dry summer intervals.",
                description = "Highly drought resistant crop grown across drier zones of Sibi, Multan, and KP. Warning: Must lead to harvesting only after maturity (45 days) to avoid HCN poisoning.",
                benefits = "Supports muscle gain in bulls, hydrates calves."
            )
        )
    }

    // Standard THI (Temperature Humidity Index) for Ruminants
    // Formula: THI = (1.8 * T + 32) - (0.55 - 0.0055 * RH) * (1.8 * T - 26)
    fun calculateTHI(tempCelsius: Float, humidityPercent: Float): Float {
        val t = tempCelsius
        val rh = humidityPercent
        val thi = (1.8f * t + 32f) - (0.55f - (0.0055f * rh)) * (1.8f * t - 26f)
        return (thi * 10f).roundToInt() / 10f
    }

    fun getTHIStatus(thi: Float): Pair<String, String> {
        return when {
            thi < 72f -> Pair("Comfort Zone / آرام دہ والہ", "Optimal livestock productivity. Perfect for feeding. Animals feel great.")
            thi < 79f -> Pair("Mild-Moderate Stress", "Early respiratory rise. Milk drop of 5-10% possible. Needs shade and air flow.")
            thi < 89f -> Pair("Severe Stress / شدید تناؤ", "High respiration rate. Reduced fertility, feed intake dropped. Active ventilation required.")
            else -> Pair("Warning / Critical", "Extremely dangerous. Heavy heat dissipation failure. Emergency misting/fans needed!")
        }
    }
}
