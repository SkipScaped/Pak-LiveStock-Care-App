package com.example.data.weather

import com.squareup.moshi.JsonClass
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.GET
import retrofit2.http.Query
import java.util.concurrent.TimeUnit
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory

@JsonClass(generateAdapter = true)
data class OpenWeatherResponse(
    val name: String?,
    val main: MainTemp?,
    val wind: WindInfo?,
    val weather: List<WeatherDescription>?
)

@JsonClass(generateAdapter = true)
data class MainTemp(
    val temp: Float?,
    val humidity: Float?
)

@JsonClass(generateAdapter = true)
data class WindInfo(
    val speed: Float?
)

@JsonClass(generateAdapter = true)
data class WeatherDescription(
    val main: String?,
    val description: String?
)

@JsonClass(generateAdapter = true)
data class OpenMeteoResponse(
    val current: CurrentWeather?
)

@JsonClass(generateAdapter = true)
data class CurrentWeather(
    val temperature_2m: Float?,
    val relative_humidity_2m: Float?,
    val wind_speed_10m: Float?,
    val weather_code: Int?
)

interface OpenWeatherApiService {
    @GET("data/2.5/weather")
    suspend fun getWeather(
        @Query("q") query: String,
        @Query("appid") apiKey: String,
        @Query("units") units: String = "metric"
    ): OpenWeatherResponse
}

interface OpenMeteoApiService {
    @GET("v1/forecast")
    suspend fun getWeather(
        @Query("latitude") latitude: Double,
        @Query("longitude") longitude: Double,
        @Query("current") current: String = "temperature_2m,relative_humidity_2m,wind_speed_10m,weather_code"
    ): OpenMeteoResponse
}

object WeatherClient {
    private const val BASE_URL = "https://api.openweathermap.org/"

    private val moshi = Moshi.Builder()
        .addLast(KotlinJsonAdapterFactory())
        .build()

    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .build()

    val service: OpenWeatherApiService by lazy {
        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .client(okHttpClient)
            .addConverterFactory(MoshiConverterFactory.create(moshi))
            .build()
            .create(OpenWeatherApiService::class.java)
    }

    val openMeteoService: OpenMeteoApiService by lazy {
        Retrofit.Builder()
            .baseUrl("https://api.open-meteo.com/")
            .client(okHttpClient)
            .addConverterFactory(MoshiConverterFactory.create(moshi))
            .build()
            .create(OpenMeteoApiService::class.java)
    }
}
