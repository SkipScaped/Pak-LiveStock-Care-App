package com.example

import android.graphics.Bitmap
import android.graphics.ImageDecoder
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.widget.Toast
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInAccount
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.api.ApiException
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.animation.animateContentSize
import androidx.compose.ui.graphics.Brush
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.lifecycle.viewmodel.compose.viewModel
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.ui.ChatMessage
import com.example.ui.MessageSender
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.TextUnit
import com.example.data.local.AnimalEntity
import com.example.data.local.VaccineRecordEntity
import com.example.data.weather.*
import com.example.data.api.GeminiClient
import com.example.ui.DiagnosticPreset
import com.example.ui.DiagnosticUiState
import com.example.ui.LivestockViewModel
import com.example.ui.theme.MyApplicationTheme
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                MainLayout()
            }
        }
    }
}

@Composable
fun MainLayout(viewModel: LivestockViewModel = viewModel()) {
    val isLoggedIn by viewModel.isLoggedIn.collectAsState()
    val context = LocalContext.current

    Crossfade(
        targetState = isLoggedIn,
        animationSpec = androidx.compose.animation.core.tween(600),
        label = "firebase_auth_crossfade"
    ) { loggedIn ->
        if (!loggedIn) {
            FirebaseLoginScreen(viewModel)
        } else {
            var selectedTab by remember { mutableStateOf(0) }
            
            Scaffold(
                modifier = Modifier.fillMaxSize().testTag("main_scaffold"),
                topBar = {
                    HeaderBar(viewModel)
                },
                bottomBar = {
                    NavigationBar(
                        containerColor = MaterialTheme.colorScheme.surface,
                        tonalElevation = 8.dp,
                        modifier = Modifier.testTag("bottom_nav")
                    ) {
                        NavigationBarItem(
                            selected = selectedTab == 0,
                            onClick = { selectedTab = 0 },
                            icon = { Icon(Icons.Default.Dashboard, contentDescription = "Dashboard") },
                            label = { Text("Dashboard", fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                        )
                        NavigationBarItem(
                            selected = selectedTab == 1,
                            onClick = { selectedTab = 1 },
                            icon = { Icon(Icons.Default.AutoAwesome, contentDescription = "AI Scan") },
                            label = { Text("AI Scan", fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                        )
                        NavigationBarItem(
                            selected = selectedTab == 2,
                            onClick = { selectedTab = 2 },
                            icon = { Icon(Icons.Default.Grass, contentDescription = "Feed Guide") },
                            label = { Text("Feed Guide", fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                        )
                        NavigationBarItem(
                            selected = selectedTab == 3,
                            onClick = { selectedTab = 3 },
                            icon = { Icon(Icons.Default.Pets, contentDescription = "My Animals") },
                            label = { Text("My Animals", fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                        )
                        NavigationBarItem(
                            selected = selectedTab == 4,
                            onClick = { selectedTab = 4 },
                            icon = { Icon(Icons.Default.Forum, contentDescription = "AI Chat") },
                            label = { Text("AI Chat", fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                        )
                    }
                }
            ) { innerPadding ->
                Surface(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding),
                    color = MaterialTheme.colorScheme.background
                ) {
                    Crossfade(
                        targetState = selectedTab,
                        animationSpec = androidx.compose.animation.core.tween(350),
                        label = "tab_crossfade"
                    ) { tab ->
                        when (tab) {
                            0 -> DashboardScreen(viewModel)
                            1 -> AiScanScreen(viewModel)
                            2 -> FeedGuideScreen(viewModel)
                            3 -> AnimalsRosterScreen(viewModel)
                            4 -> GeminiChatScreen(viewModel)
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HeaderBar(viewModel: LivestockViewModel) {
    val currentUserName by viewModel.currentUserName.collectAsState()
    val currentUserEmail by viewModel.currentUserEmail.collectAsState()
    var logoutMenuExpanded by remember { mutableStateOf(false) }

    TopAppBar(
        colors = TopAppBarDefaults.topAppBarColors(
            containerColor = MaterialTheme.colorScheme.primary,
            titleContentColor = Color.White
        ),
        title = {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.HealthAndSafety,
                    contentDescription = "App Logo Logo",
                    tint = MaterialTheme.colorScheme.tertiaryContainer,
                    modifier = Modifier.size(28.dp)
                )
                Column {
                    Text(
                        text = "Pak Livestock Care",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Black,
                        letterSpacing = 0.5.sp
                    )
                    Text(
                        text = "پاکستان لائیوسٹاک کیئر",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium,
                        color = Color.White.copy(alpha = 0.85f),
                        letterSpacing = 0.2.sp
                    )
                }
            }
        },
        actions = {
            Box(modifier = Modifier.padding(end = 8.dp)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .background(Color.White.copy(alpha = 0.15f), RoundedCornerShape(20.dp))
                        .clickable { logoutMenuExpanded = true }
                        .padding(horizontal = 10.dp, vertical = 4.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(24.dp)
                            .background(Color.White, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = (currentUserName ?: "F").take(1).uppercase(),
                            color = MaterialTheme.colorScheme.primary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp
                        )
                    }
                    Spacer(modifier = Modifier.width(6.dp))
                    Icon(
                        Icons.Default.ArrowDropDown,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(16.dp)
                    )
                }

                DropdownMenu(
                    expanded = logoutMenuExpanded,
                    onDismissRequest = { logoutMenuExpanded = false }
                ) {
                    DropdownMenuItem(
                        text = {
                            Column {
                                Text(currentUserName ?: "Farmer Owner", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                Text(currentUserEmail ?: "", fontSize = 11.sp, color = Color.Gray)
                            }
                        },
                        onClick = {}
                    )
                    Divider()
                    DropdownMenuItem(
                        text = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Logout, contentDescription = "Logout", tint = Color.Red, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Sign Out of Firebase", color = Color.Red, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            }
                        },
                        onClick = {
                            logoutMenuExpanded = false
                            viewModel.logout()
                        }
                    )
                }
            }
        }
    )
}

@Composable
fun FirebaseLoginScreen(viewModel: LivestockViewModel) {
    val context = LocalContext.current
    val authLoading by viewModel.authLoading.collectAsState()
    val authError by viewModel.authError.collectAsState()

    var showAccountChooser by remember { mutableStateOf(false) }
    var selectedGDistrict by remember { mutableStateOf("Sahiwal") }
    var districtDropdownExpanded by remember { mutableStateOf(false) }

    val gso = remember {
        GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestEmail()
            .requestProfile()
            .build()
    }
    val googleSignInClient = remember {
        try {
            GoogleSignIn.getClient(context, gso)
        } catch (e: Exception) {
            null
        }
    }

    val googleSignInLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        try {
            val data = result.data
            val task = GoogleSignIn.getSignedInAccountFromIntent(data)
            val account = task.getResult(ApiException::class.java)
            if (account != null) {
                val email = account.email ?: ""
                val name = account.displayName ?: ""
                viewModel.loginWithGoogle(email, name, selectedGDistrict) { ok ->
                    if (ok) {
                        Toast.makeText(context, "Successfully logged in as $name via Google Secure Auth!", Toast.LENGTH_LONG).show()
                    }
                }
            } else {
                Toast.makeText(context, "Google Sign-In returned empty account data.", Toast.LENGTH_LONG).show()
            }
        } catch (e: Exception) {
            val statusCode = (e as? ApiException)?.statusCode ?: -1
            val errorMessage = when (statusCode) {
                7 -> "Network Error. Please check your connection."
                10 -> "Developer Key/SHA1 mismatch. Launching Secure Google Web login..."
                12501 -> "Sign-in cancelled by user."
                else -> "Sign-in API failed or cancelled (code: $statusCode). Launching Secure Google Web login..."
            }
            Toast.makeText(context, errorMessage, Toast.LENGTH_LONG).show()
            // Always show the beautiful fallback on error so they're never locked out
            showAccountChooser = true
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f),
                        MaterialTheme.colorScheme.background
                    )
                )
            )
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .widthIn(max = 440.dp)
                .animateContentSize(),
            shape = RoundedCornerShape(28.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 6.dp)
        ) {
            Column(
                modifier = Modifier
                    .padding(32.dp)
                    .fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Header Brand Icon Group
                Box(
                    modifier = Modifier
                        .size(64.dp)
                        .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.1f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.HealthAndSafety,
                        contentDescription = "Logo",
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(38.dp)
                    )
                }

                Text(
                     text = "Pak Livestock Care\nموبائل لائیو سٹاک پورٹل",
                     fontSize = 22.sp,
                     fontWeight = FontWeight.Black,
                     textAlign = TextAlign.Center,
                     lineHeight = 28.sp,
                     color = MaterialTheme.colorScheme.primary
                )

                Text(
                     text = "Secure Google Sign-In is required to access your digital herd registry, weather-correlated fodder guides, and live AI diagnostics.",
                     fontSize = 12.sp,
                     textAlign = TextAlign.Center,
                     color = Color.Gray,
                     lineHeight = 16.sp,
                     modifier = Modifier.padding(horizontal = 8.dp)
                )

                Spacer(modifier = Modifier.height(8.dp))

                // Farm District selection (so we can log in with a customized district right away!)
                Box(modifier = Modifier.fillMaxWidth()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { districtDropdownExpanded = true }
                    ) {
                        OutlinedTextField(
                            value = selectedGDistrict,
                            onValueChange = {},
                            label = { Text("Your Farm's District (ضلع)") },
                            leadingIcon = { Icon(Icons.Default.Map, null, tint = MaterialTheme.colorScheme.primary) },
                            trailingIcon = { Icon(Icons.Default.ArrowDropDown, null) },
                            readOnly = true,
                            enabled = false,
                            colors = androidx.compose.material3.OutlinedTextFieldDefaults.colors(
                                disabledTextColor = MaterialTheme.colorScheme.onSurface,
                                disabledBorderColor = MaterialTheme.colorScheme.outline,
                                disabledLeadingIconColor = MaterialTheme.colorScheme.primary,
                                disabledTrailingIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                                disabledLabelColor = MaterialTheme.colorScheme.onSurfaceVariant,
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("google_login_district_input"),
                            shape = RoundedCornerShape(12.dp)
                        )
                    }
                    DropdownMenu(
                        expanded = districtDropdownExpanded,
                        onDismissRequest = { districtDropdownExpanded = false }
                    ) {
                        WeatherRiskManager.availableDistricts.forEach { district ->
                            DropdownMenuItem(
                                text = { Text(district) },
                                onClick = {
                                    selectedGDistrict = district
                                    districtDropdownExpanded = false
                                }
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))

                if (authError != null) {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.Error, contentDescription = null, tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(authError!!, color = MaterialTheme.colorScheme.onErrorContainer, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                // Official Styled Google Button
                Button(
                    onClick = {
                        try {
                            val client = googleSignInClient
                            if (client != null) {
                                val signInIntent = client.signInIntent
                                googleSignInLauncher.launch(signInIntent)
                            } else {
                                Toast.makeText(context, "Google Play Services not supported on this device. Opening Web fallback login...", Toast.LENGTH_SHORT).show()
                                showAccountChooser = true
                            }
                        } catch (e: Exception) {
                            Toast.makeText(context, "Google authentication could not start. Opening Web fallback login...", Toast.LENGTH_SHORT).show()
                            showAccountChooser = true
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .testTag("google_login_button"),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color.White,
                        contentColor = Color.Black
                    ),
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.dp, Color.LightGray.copy(alpha = 0.8f)),
                    enabled = !authLoading
                ) {
                    if (authLoading) {
                        CircularProgressIndicator(color = MaterialTheme.colorScheme.primary, modifier = Modifier.size(24.dp))
                    } else {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center
                        ) {
                            // Custom Drawn multi-color Google logo
                            Row(
                                modifier = Modifier.padding(end = 12.dp),
                                horizontalArrangement = Arrangement.spacedBy(1.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("G", color = Color(0xFF4285F4), fontWeight = FontWeight.Black, fontSize = 18.sp)
                                Text("o", color = Color(0xFFEA4335), fontWeight = FontWeight.Black, fontSize = 18.sp)
                                Text("o", color = Color(0xFFFBBC05), fontWeight = FontWeight.Black, fontSize = 18.sp)
                                Text("g", color = Color(0xFF4285F4), fontWeight = FontWeight.Black, fontSize = 18.sp)
                                Text("l", color = Color(0xFF34A853), fontWeight = FontWeight.Black, fontSize = 18.sp)
                                Text("e", color = Color(0xFFEA4335), fontWeight = FontWeight.Black, fontSize = 18.sp)
                            }
                            Text(
                                "Sign in with Google",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.DarkGray
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))

                TextButton(
                    onClick = { showAccountChooser = true },
                    modifier = Modifier.testTag("google_login_fallback_link")
                ) {
                    Text(
                        "Can't sign in? Use Google Web Auth fallback",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.Medium
                    )
                }

                Text(
                     text = "🔒 Single sign-on authenticated via Google Play Services.",
                     fontSize = 10.sp,
                     color = Color.LightGray,
                     textAlign = TextAlign.Center
                )
            }
        }
    }

    if (showAccountChooser) {
        GoogleAccountChooserDialog(
            onAccountSelected = { email, name ->
                showAccountChooser = false
                viewModel.loginWithGoogle(email, name, selectedGDistrict) { ok ->
                    if (ok) {
                        Toast.makeText(context, "Successfully logged in as $name via Google Secure Auth!", Toast.LENGTH_LONG).show()
                    }
                }
            },
            onDismiss = { showAccountChooser = false }
        )
    }
}

@Composable
fun GoogleAccountChooserDialog(
    onAccountSelected: (email: String, name: String) -> Unit,
    onDismiss: () -> Unit
) {
    var customName by remember { mutableStateOf("") }
    var customEmail by remember { mutableStateOf("") }
    var customError by remember { mutableStateOf<String?>(null) }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .testTag("google_account_chooser"),
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            elevation = CardDefaults.cardElevation(defaultElevation = 16.dp)
        ) {
            Column(
                modifier = Modifier
                    .padding(24.dp)
                    .fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Google logo
                Row(
                    horizontalArrangement = Arrangement.spacedBy(2.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("G", color = Color(0xFF4285F4), fontWeight = FontWeight.Black, fontSize = 24.sp)
                    Text("o", color = Color(0xFFEA4335), fontWeight = FontWeight.Black, fontSize = 24.sp)
                    Text("o", color = Color(0xFFFBBC05), fontWeight = FontWeight.Black, fontSize = 24.sp)
                    Text("g", color = Color(0xFF4285F4), fontWeight = FontWeight.Black, fontSize = 24.sp)
                    Text("l", color = Color(0xFF34A853), fontWeight = FontWeight.Black, fontSize = 24.sp)
                    Text("e", color = Color(0xFFEA4335), fontWeight = FontWeight.Black, fontSize = 24.sp)
                }

                Text(
                    text = "Google Account Secure Sign-In",
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp,
                    color = Color.Black
                )

                Text(
                    text = "Sign in directly with your Google Account details to link your digital herd with Pak Livestock Care.",
                    fontSize = 11.sp,
                    color = Color.Gray,
                    textAlign = TextAlign.Center,
                    lineHeight = 15.sp
                )

                OutlinedTextField(
                    value = customName,
                    onValueChange = { customName = it },
                    label = { Text("Google Full Name") },
                    leadingIcon = { Icon(Icons.Default.Person, null, tint = Color(0xFF4285F4)) },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.Black,
                        unfocusedTextColor = Color.Black,
                        focusedBorderColor = Color(0xFF4285F4),
                        unfocusedBorderColor = Color.LightGray,
                        focusedLabelColor = Color(0xFF4285F4),
                        unfocusedLabelColor = Color.Gray
                    ),
                    modifier = Modifier.fillMaxWidth().testTag("custom_google_name")
                )

                OutlinedTextField(
                    value = customEmail,
                    onValueChange = { customEmail = it },
                    label = { Text("Google Email Address") },
                    leadingIcon = { Icon(Icons.Default.Email, null, tint = Color(0xFF4285F4)) },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.Black,
                        unfocusedTextColor = Color.Black,
                        focusedBorderColor = Color(0xFF4285F4),
                        unfocusedBorderColor = Color.LightGray,
                        focusedLabelColor = Color(0xFF4285F4),
                        unfocusedLabelColor = Color.Gray
                    ),
                    modifier = Modifier.fillMaxWidth().testTag("custom_google_email")
                )

                if (customError != null) {
                    Text(customError!!, color = Color.Red, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextButton(onClick = onDismiss) {
                        Text("Cancel", color = Color.Gray)
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = {
                            if (customName.isBlank() || customEmail.isBlank()) {
                                customError = "Please specify Name and Email"
                            } else if (!customEmail.contains("@") || !customEmail.contains(".")) {
                                customError = "Specify a valid email format"
                            } else {
                                onAccountSelected(customEmail, customName)
                            }
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFF4285F4),
                            contentColor = Color.White
                        ),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("Sign In")
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "To continue, Google will share your verified identity card and language preferences securely with Pak Livestock Care.",
                    fontSize = 10.sp,
                    color = Color.LightGray,
                    textAlign = TextAlign.Center,
                    lineHeight = 14.sp
                )
            }
        }
    }
}

// ==================== DASHBOARD SCREEN ====================
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun DashboardScreen(viewModel: LivestockViewModel) {
    val selectedDistrict by viewModel.selectedDistrict.collectAsState()
    val weather by viewModel.currentWeather.collectAsState()
    val animals by viewModel.animals.collectAsState()
    
    val thiValue = WeatherRiskManager.calculateTHI(weather.temperatureCelsius, weather.relativeHumidityPercent)
    val (thiStatus, thiDesc) = WeatherRiskManager.getTHIStatus(thiValue)

    var showDistrictPicker by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // District Selector Header
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Selected District / ضلع",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            text = "$selectedDistrict, ${weather.province}",
                            fontSize = 24.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                    }
                    Button(
                        onClick = { showDistrictPicker = true },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.testTag("btn_change_district")
                    ) {
                        Icon(Icons.Default.Map, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Change", fontSize = 13.sp)
                    }
                }
            }
        }

        // Quick Stats row
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                StatCard(
                    title = "My Roster",
                    urdu = "کل جانور",
                    value = "${animals.size} Head",
                    icon = Icons.Default.Pets,
                    color = MaterialTheme.colorScheme.secondary,
                    modifier = Modifier.weight(1f)
                )
                StatCard(
                    title = "Bluetongue",
                    urdu = "نیلی زبان خطرہ",
                    value = if (selectedDistrict in listOf("Sahiwal", "Hyderabad")) "Severe Risk" else "Moderate",
                    icon = Icons.Default.BugReport,
                    color = if (selectedDistrict in listOf("Sahiwal", "Hyderabad")) Color(0xFFD32F2F) else Color(0xFFE65100),
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Live Weather Status Card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.15f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                Icons.Default.Cloud,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(32.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                "Live Weather Forecast",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Box(
                            modifier = Modifier
                                .background(MaterialTheme.colorScheme.inverseOnSurface, CircleShape)
                                .padding(horizontal = 12.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = weather.condition,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    FlowRow(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        maxItemsInEachRow = 3
                    ) {
                        WeatherMetricItem(
                            label = "Temperature",
                            value = "${weather.temperatureCelsius}°C",
                            icon = Icons.Default.Thermostat
                        )
                        WeatherMetricItem(
                            label = "Humidity",
                            value = "${weather.relativeHumidityPercent}%",
                            icon = Icons.Default.WaterDrop
                        )
                        WeatherMetricItem(
                            label = "Wind Speed",
                            value = "${weather.windSpeedKmh} km/h",
                            icon = Icons.Default.WindPower
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))
                    Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.1f))
                    Spacer(modifier = Modifier.height(12.dp))

                    // THI heat stress card
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(
                                color = when {
                                    thiValue < 72f -> Color(0xFFE8F5E9)
                                    thiValue < 79f -> Color(0xFFFFF3E0)
                                    else -> Color(0xFFFFEBEE)
                                },
                                shape = RoundedCornerShape(12.dp)
                            )
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.LocalFireDepartment,
                            contentDescription = "Heat stress status",
                            tint = when {
                                thiValue < 72f -> Color(0xFF2E7D32)
                                thiValue < 79f -> Color(0xFFEF6C00)
                                else -> Color(0xFFC62828)
                            },
                            modifier = Modifier.size(28.dp)
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "THI Index: $thiValue ($thiStatus)",
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                color = Color.Black
                            )
                            Text(
                                text = thiDesc,
                                fontSize = 11.sp,
                                color = Color.DarkGray,
                                lineHeight = 14.sp
                            )
                        }
                    }
                }
            }
        }

        // Outbreak Predictions
        item {
            Row(
                modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    Icons.Default.Coronavirus,
                    contentDescription = null,
                    tint = Color(0xFFC62828),
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                    Text(
                        "Disease Outbreak Predictions",
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        "موسمی بیماریوں کی پیش گوئی",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                    )
                }
            }
        }

        items(weather.outbreaksPredicted) { prediction ->
            OutbreakRiskCard(prediction)
        }

        // AI Climate & Grazing Advisor Card
        item {
            val liveAssessment by viewModel.liveWeatherAssessment.collectAsState()
            val isWeatherLoading by viewModel.isWeatherLoading.collectAsState()

            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.25f)),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.12f)),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Psychology,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(28.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    "AI Climate & Grazing Advisor",
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                                Text(
                                    "اے آئی موسمیاتی اور چرائی مشیر",
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.6f)
                                )
                            }
                        }
                        
                        if (isWeatherLoading) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(20.dp),
                                strokeWidth = 2.dp,
                                color = MaterialTheme.colorScheme.primary
                            )
                        } else {
                            val apiKeyArg = GeminiClient.getApiKey()
                            val isLiveGemini = apiKeyArg.isNotBlank() && apiKeyArg != "MY_GEMINI_API_KEY"
                            Box(
                                modifier = Modifier
                                    .background(
                                        if (isLiveGemini) Color(0xFFE8F5E9) else Color(0xFFFFECEB),
                                        CircleShape
                                    )
                                    .padding(horizontal = 8.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = if (isLiveGemini) "Live Advisor" else "Simulation Mode",
                                    fontSize = 9.sp,
                                    color = if (isLiveGemini) Color(0xFF2E7D32) else Color(0xFFD32F2F),
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    if (isWeatherLoading && liveAssessment.isNullOrBlank()) {
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp),
                            horizontalArrangement = Arrangement.Center,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Analyzing localized weather parameters for grazing...",
                                fontSize = 12.sp,
                                color = Color.Gray,
                                fontStyle = androidx.compose.ui.text.font.FontStyle.Italic
                            )
                        }
                    } else if (!liveAssessment.isNullOrBlank()) {
                        // Display the formatted assessment text beautifully
                        Text(
                            text = liveAssessment ?: "",
                            fontSize = 13.sp,
                            lineHeight = 18.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(bottom = 4.dp)
                        )
                    } else {
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp),
                            horizontalArrangement = Arrangement.Center,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Button(
                                onClick = { viewModel.runGeminiWeatherAssessment(selectedDistrict, weather) }
                            ) {
                                Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Trigger Climate & Grazing Assessment")
                            }
                        }
                    }
                }
            }
        }
    }

    // District Selector Dialog
    if (showDistrictPicker) {
        Dialog(onDismissRequest = { showDistrictPicker = false }) {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .padding(24.dp)
                        .fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "Select District / ضلع منتخب کریں",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(bottom = 12.dp)
                    )
                    Divider()
                    Spacer(modifier = Modifier.height(12.dp))

                    LazyColumn(
                        modifier = Modifier.height(280.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        items(WeatherRiskManager.availableDistricts) { district ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        viewModel.selectDistrict(district)
                                        showDistrictPicker = false
                                    }
                                    .padding(vertical = 12.dp, horizontal = 16.dp)
                                    .background(
                                        if (district == selectedDistrict) MaterialTheme.colorScheme.primaryContainer else Color.Transparent,
                                        RoundedCornerShape(8.dp)
                                    ),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = district,
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = if (district == selectedDistrict) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                                )
                                if (district == selectedDistrict) {
                                    Icon(
                                        Icons.Default.CheckCircle,
                                        contentDescription = "selected",
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                            }
                        }
                    }
                    Spacer(modifier = Modifier.height(16.dp))
                    TextButton(
                        onClick = { showDistrictPicker = false },
                        modifier = Modifier.align(Alignment.End)
                    ) {
                        Text("Cancel", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun StatCard(
    title: String,
    urdu: String,
    value: String,
    icon: ImageVector,
    color: Color,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.height(104.dp),
        colors = CardDefaults.cardColors(containerColor = color.copy(alpha = 0.08f)),
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.dp, color.copy(alpha = 0.3f))
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(12.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(title, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = color)
                    Text(urdu, fontSize = 9.sp, color = Color.Gray)
                }
                Icon(icon, contentDescription = null, tint = color, modifier = Modifier.size(20.dp))
            }
            Text(value, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold, color = color)
        }
    }
}

@Composable
fun WeatherMetricItem(label: String, value: String, icon: ImageVector) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.padding(vertical = 4.dp)
    ) {
        Box(
            modifier = Modifier
                .size(36.dp)
                .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.08f), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
        }
        Spacer(modifier = Modifier.width(10.dp))
        Column {
            Text(label, fontSize = 11.sp, color = Color.Gray)
            Text(value, fontSize = 14.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun OutbreakRiskCard(prediction: DiseasePrediction) {
    val riskColor = when (prediction.riskLevel.lowercase()) {
        "severe" -> Color(0xFFD32F2F)
        "high" -> Color(0xFFEF6C00)
        "moderate" -> Color(0xFFFBC02D)
        else -> Color(0xFF388E3C)
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(14.dp),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.1f))
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = prediction.diseaseName,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Box(
                    modifier = Modifier
                        .background(riskColor.copy(alpha = 0.12f), RoundedCornerShape(24.dp))
                        .border(1.dp, riskColor.copy(alpha = 0.3f), RoundedCornerShape(24.dp))
                        .padding(horizontal = 10.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = "${prediction.riskLevel} Risk",
                        fontSize = 11.sp,
                        color = riskColor,
                        fontWeight = FontWeight.Black
                    )
                }
            }

            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = prediction.description,
                fontSize = 12.sp,
                color = Color.Gray,
                lineHeight = 16.sp,
                modifier = Modifier.padding(bottom = 10.dp)
            )

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.05f), RoundedCornerShape(8.dp))
                    .padding(10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    Icons.Default.Verified,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Column {
                    Text("Recommended Care Profile", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    Text(prediction.recommendedAction, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface, lineHeight = 14.sp)
                }
            }
        }
    }
}

// ==================== AI POWERED AGENT DIAGNOSTICS ====================
@Composable
fun AiScanScreen(viewModel: LivestockViewModel) {
    val selectedPreset by viewModel.selectedPreset.collectAsState()
    val customBitmap by viewModel.customBitmap.collectAsState()
    val diagnosticState by viewModel.diagnosticState.collectAsState()
    val context = LocalContext.current

    // Set up photo picker launcher
    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            try {
                val bitmap = if (Build.VERSION.SDK_INT < 28) {
                    MediaStore.Images.Media.getBitmap(context.contentResolver, uri)
                } else {
                    val source = ImageDecoder.createSource(context.contentResolver, uri)
                    ImageDecoder.decodeBitmap(source)
                }
                viewModel.setCustomBitmap(bitmap)
            } catch (e: Exception) {
                Toast.makeText(context, "Error decoding image: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Explanatory Banner
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.06f)),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.2f))
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        Icons.Default.AutoAwesome,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(36.dp)
                    )
                    Column {
                        Text(
                            text = "AI-Powered Diagnostics (Gemini 3.5)",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            text = "Select one of the pre-loaded medical presets representing different clinical scenarios in Pakistani farms, or upload your own, and consult Google Gemini for diagnostics and therapy outlines.",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f),
                            lineHeight = 15.sp
                        )
                    }
                }
            }
        }

        // Section header for Presets
        item {
            Column {
                Text(
                    text = "Select Farm Scenario Presets",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Black
                )
                Text(
                    text = "تشخیصی لیول منتخب کریں",
                    fontSize = 11.sp,
                    color = Color.Gray
                )
            }
        }

        // Horizontal Row of presets
        item {
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.fillMaxWidth().testTag("preset_row")
            ) {
                items(viewModel.diagnosticPresets) { preset ->
                    val isSelected = selectedPreset?.id == preset.id
                    Card(
                        modifier = Modifier
                            .width(140.dp)
                            .clickable { viewModel.selectPreset(preset) },
                        border = BorderStroke(
                            width = if (isSelected) 2.dp else 1.dp,
                            color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline.copy(alpha = 0.15f)
                        ),
                        colors = CardDefaults.cardColors(
                            containerColor = if (isSelected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface
                        ),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Column(
                            modifier = Modifier.padding(10.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            // Render placeholder badge
                            Box(
                                modifier = Modifier
                                    .size(48.dp)
                                    .background(
                                        if (isSelected) MaterialTheme.colorScheme.primary.copy(alpha = 0.2f) else MaterialTheme.colorScheme.primary.copy(alpha = 0.08f),
                                        CircleShape
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                AsyncImage(
                                    model = preset.imageUrl,
                                    contentDescription = null,
                                    modifier = Modifier.size(24.dp)
                                )
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = preset.animalType,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = preset.potentialDisease.split(" ").firstOrNull() ?: "",
                                fontSize = 11.sp,
                                color = Color.Gray,
                                maxLines = 1,
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }
            }
        }

        // Custom image upload card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(14.dp),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.15f))
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    if (customBitmap != null) {
                        Image(
                            bitmap = customBitmap!!.asImageBitmap(),
                            contentDescription = "Custom upload",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(160.dp)
                                .clip(RoundedCornerShape(8.dp))
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            "Custom Livestock Photo Selected",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    } else {
                        Button(
                            onClick = { photoPickerLauncher.launch("image/*") },
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.fillMaxWidth().height(48.dp).testTag("btn_custom_upload")
                        ) {
                            Icon(Icons.Default.CloudUpload, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Upload custom/live cattle photo")
                        }
                    }
                }
            }
        }

        // Selected Preset details
        if (selectedPreset != null) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(
                            text = "PRESET PATHOLOGY INFORMATION",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = selectedPreset!!.symptomTitle,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        val labelColor = if (selectedPreset!!.potentialDisease.contains("Healthy")) Color(0xFF388E3C) else Color(0xFFD32F2F)
                        Text(
                            text = "Indication: ${selectedPreset!!.potentialDisease}",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = labelColor
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = selectedPreset!!.description,
                            fontSize = 11.sp,
                            color = Color.DarkGray,
                            lineHeight = 15.sp
                        )
                    }
                }
            }
        }

        // Diagnose Trigger Button
        item {
            Button(
                onClick = { viewModel.runAiDiagnosis() },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(54.dp)
                    .testTag("btn_diagnose"),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(Icons.Default.AutoMode, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("SCAN WITH GEMINI API", fontSize = 16.sp, fontWeight = FontWeight.Black)
            }
        }

        // Diagnostics Result Output
        item {
            when (val state = diagnosticState) {
                is DiagnosticUiState.Idle -> {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(100.dp)
                            .background(Color.Gray.copy(alpha = 0.05f), RoundedCornerShape(12.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            "Scan results will load below.",
                            fontSize = 13.sp,
                            color = Color.Gray
                        )
                    }
                }
                is DiagnosticUiState.Loading -> {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        CircularProgressIndicator()
                        Spacer(modifier = Modifier.height(10.dp))
                        Text("Gemini AI analyzing physiological structures...", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    }
                }
                is DiagnosticUiState.Success -> {
                    Card(
                        modifier = Modifier.fillMaxWidth().testTag("diagnostic_output_card"),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        Icons.Default.VerifiedUser,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(24.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = "VETERINARY DIAGNOSIS RESULT",
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                }

                                if (state.isSimulated) {
                                    Box(
                                        modifier = Modifier
                                            .background(Color(0xFFE65100).copy(alpha = 0.1f), RoundedCornerShape(8.dp))
                                            .padding(horizontal = 8.dp, vertical = 2.dp)
                                    ) {
                                        Text("Simulator Profile", fontSize = 9.sp, color = Color(0xFFE65100), fontWeight = FontWeight.Bold)
                                    }
                                } else {
                                    Box(
                                        modifier = Modifier
                                            .background(Color(0xFF388E3C).copy(alpha = 0.1f), RoundedCornerShape(8.dp))
                                            .padding(horizontal = 8.dp, vertical = 2.dp)
                                    ) {
                                        Text("Live Gemini", fontSize = 9.sp, color = Color(0xFF388E3C), fontWeight = FontWeight.Bold)
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(12.dp))
                            Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.15f))
                            Spacer(modifier = Modifier.height(12.dp))

                            // Scrollable formatted output text
                            Text(
                                text = state.response,
                                fontSize = 13.sp,
                                color = MaterialTheme.colorScheme.onSurface,
                                lineHeight = 18.sp,
                                modifier = Modifier.padding(bottom = 6.dp)
                            )
                        }
                    }
                }
                is DiagnosticUiState.Error -> {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)
                    ) {
                        Row(
                            modifier = Modifier.padding(14.dp),
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.Error, contentDescription = null, tint = MaterialTheme.colorScheme.error)
                            Text(state.message, color = MaterialTheme.colorScheme.onErrorContainer, fontSize = 13.sp)
                        }
                    }
                }
            }
        }
    }
}

// ==================== FEED & CLINICS GUIDE ====================
@Composable
fun FeedGuideScreen(viewModel: LivestockViewModel) {
    var selectedTab by remember { mutableStateOf(0) } // 0 = Food/Fodder, 1 = Vet Clinics

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Tab Headers list
        TabRow(
            selectedTabIndex = selectedTab,
            containerColor = Color.Transparent,
            modifier = Modifier.fillMaxWidth().testTag("feed_tab")
        ) {
            Tab(
                selected = selectedTab == 0,
                onClick = { selectedTab = 0 },
                text = { Text("Local Fodder Guide", fontWeight = FontWeight.Bold) }
            )
            Tab(
                selected = selectedTab == 1,
                onClick = { selectedTab = 1 },
                text = { Text("Veterinary Centers", fontWeight = FontWeight.Bold) }
            )
        }

        Spacer(modifier = Modifier.height(4.dp))

        if (selectedTab == 0) {
            FodderGuideLayout()
        } else {
            ClinicsDirectoryLayout(viewModel)
        }
    }
}

@Composable
fun FodderGuideLayout() {
    val fodderData = WeatherRiskManager.getExtendedFodderOptions()

    LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        items(fodderData) { fodder ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.12f))
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = fodder.name,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Box(
                            modifier = Modifier
                                .background(MaterialTheme.colorScheme.secondary.copy(alpha = 0.08f), CircleShape)
                                .padding(horizontal = 8.dp, vertical = 2.dp)
                        ) {
                            Text(fodder.type, fontSize = 10.sp, color = MaterialTheme.colorScheme.secondary, fontWeight = FontWeight.Bold)
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))
                    Text(text = fodder.description, fontSize = 12.sp, color = Color.Gray, lineHeight = 16.sp)
                    Spacer(modifier = Modifier.height(10.dp))
                    Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.08f))
                    Spacer(modifier = Modifier.height(8.dp))

                    Row(modifier = Modifier.fillMaxWidth()) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Suitable For", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color.Gray)
                            Text(fodder.suitability, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                        }
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Benefit Yield", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color.Gray)
                            Text(fodder.benefits, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.primary)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ClinicsDirectoryLayout(viewModel: LivestockViewModel) {
    val selectedDistrict by viewModel.selectedDistrict.collectAsState()
    val clinics = WeatherRiskManager.getClinicsForDistrict(selectedDistrict)

    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        // Dynamic District Info Header
        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.15f)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier.padding(12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.LocationOn,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Vet Centers Near $selectedDistrict Area",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                }
                Box(
                    modifier = Modifier
                        .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.1f), CircleShape)
                        .padding(horizontal = 8.dp, vertical = 2.dp)
                ) {
                    Text("Auto-Localized", fontSize = 9.sp, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                }
            }
        }

        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.weight(1f)) {
            items(clinics) { clinic ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.12f))
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(44.dp)
                                .background(Color(0xFFE8F5E9), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.LocalHospital, contentDescription = null, tint = Color(0xFF2E7D32))
                        }

                        Column(modifier = Modifier.weight(1f)) {
                            Text(clinic.name, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                            Text(clinic.location, fontSize = 12.sp, color = Color.Gray)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(clinic.specialty, fontSize = 11.sp, color = Color.DarkGray, lineHeight = 14.sp)
                            Spacer(modifier = Modifier.height(6.dp))
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Phone, contentDescription = null, modifier = Modifier.size(12.dp), tint = Color.Gray)
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(clinic.phone, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                            }
                        }
                    }
                }
            }
        }
    }
}


// ==================== MY ANIMALS ROSTER & VACCINATIONS ====================
@Composable
fun AnimalsRosterScreen(viewModel: LivestockViewModel) {
    val animals by viewModel.animals.collectAsState()
    val vaccines by viewModel.vaccineRecords.collectAsState()

    var showAddAnimalDialog by remember { mutableStateOf(false) }
    var expandedAnimalId by remember { mutableStateOf<Int?>(null) }
    var showAddVaccineDialogState by remember { mutableStateOf<Int?>(null) } // holds animal ID

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Register Animal Floating Action Banner
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text("Registered Livestock", fontSize = 18.sp, fontWeight = FontWeight.Black)
                Text("رجسٹرڈ مویشیوں کی فہرست", fontSize = 12.sp, color = Color.Gray)
            }
            Button(
                onClick = { showAddAnimalDialog = true },
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.testTag("btn_register_new")
            ) {
                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Register", fontSize = 13.sp)
            }
        }

        Spacer(modifier = Modifier.height(4.dp))

        if (animals.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .background(Color.Gray.copy(alpha = 0.05f), RoundedCornerShape(12.dp)),
                contentAlignment = Alignment.Center
            ) {
                Text("No animals registered yet. Click Register above to add your cow, sheep, or buffalo!")
            }
        } else {
            LazyColumn(
                modifier = Modifier.weight(1f).testTag("roster_list"),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(animals) { animal ->
                    val isExpanded = expandedAnimalId == animal.id
                    val animalVaccines = vaccines.filter { it.animalId == animal.id }

                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .animateContentSize()
                            .clickable { expandedAnimalId = if (isExpanded) null else animal.id }
                            .testTag("animal_card_${animal.id}"),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = BorderStroke(
                            width = if (isExpanded) 1.5.dp else 1.dp,
                            color = if (isExpanded) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline.copy(alpha = 0.1f)
                        )
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier
                                            .size(46.dp)
                                            .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.08f), CircleShape),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = when (animal.type.lowercase().trim()) {
                                                "cow" -> Icons.Default.AirportShuttle // represent cows
                                                "buffalo", "bull" -> Icons.Default.Agriculture // cattle
                                                "sheep", "fat-tailed sheep" -> Icons.Default.CrueltyFree // sheep
                                                else -> Icons.Default.Pets
                                            },
                                            contentDescription = null,
                                            tint = MaterialTheme.colorScheme.primary,
                                            modifier = Modifier.size(24.dp)
                                        )
                                    }

                                    Spacer(modifier = Modifier.width(12.dp))

                                    Column {
                                        Text(animal.name, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                                        Text("${animal.breed} • ${animal.ageInMonths} mths", fontSize = 12.sp, color = Color.Gray)
                                    }
                                }

                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .background(MaterialTheme.colorScheme.secondary.copy(alpha = 0.08f), RoundedCornerShape(20.dp))
                                            .padding(horizontal = 10.dp, vertical = 2.dp)
                                    ) {
                                        Text(animal.district, fontSize = 11.sp, color = MaterialTheme.colorScheme.secondary, fontWeight = FontWeight.Bold)
                                    }
                                    IconButton(
                                        onClick = { viewModel.removeAnimal(animal.id) },
                                        modifier = Modifier.testTag("btn_delete_animal_${animal.id}")
                                    ) {
                                        Icon(Icons.Default.Delete, contentDescription = "Delete", tint = Color.Gray, modifier = Modifier.size(20.dp))
                                    }
                                }
                            }

                            // Shows minimal vaccine tags
                            Row(
                                modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                if (animalVaccines.isEmpty()) {
                                    Text("⚠️ No Vaccines Logged", fontSize = 10.sp, color = Color(0xFFC62828), fontWeight = FontWeight.Bold)
                                } else {
                                    animalVaccines.take(2).forEach { record ->
                                        Box(
                                            modifier = Modifier
                                                .background(Color(0xFFE8F5E9), RoundedCornerShape(8.dp))
                                                .padding(horizontal = 8.dp, vertical = 2.dp)
                                        ) {
                                            Text(
                                                text = "${record.vaccineName.split(" ").firstOrNull()}: Administered",
                                                fontSize = 9.sp,
                                                color = Color(0xFF2E7D32),
                                                fontWeight = FontWeight.Bold
                                            )
                                        }
                                    }
                                    if (animalVaccines.size > 2) {
                                        Text("+${animalVaccines.size - 2} more", fontSize = 9.sp, color = Color.Gray)
                                    }
                                }
                            }

                            // Expanded view of vaccines details
                            if (isExpanded) {
                                Spacer(modifier = Modifier.height(14.dp))
                                Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.1f))
                                Spacer(modifier = Modifier.height(10.dp))

                                // Dynamic breed prescription card recommendations
                                val recommendation = LivestockViewModel.getRecommendationForBreed(animal.breed)
                                Card(
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.4f)),
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp)
                                ) {
                                    Column(modifier = Modifier.padding(12.dp)) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                                        ) {
                                            Icon(Icons.Default.Grass, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                                            Text("Automated Breed Nutrition Plan", fontWeight = FontWeight.ExtraBold, fontSize = 13.sp, color = MaterialTheme.colorScheme.primary)
                                        }
                                        Text(recommendation.localNameUrdu, fontWeight = FontWeight.Bold, fontSize = 11.sp, color = Color.DarkGray, modifier = Modifier.padding(top = 2.dp))
                                        Spacer(modifier = Modifier.height(8.dp))
                                        Text("Recommended Daily Diet (روزانہ چارے کا فارمولا):", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSecondaryContainer)
                                        Text(recommendation.dailyFodderFormula, fontSize = 12.sp, lineHeight = 16.sp, color = Color.Black)
                                        Spacer(modifier = Modifier.height(6.dp))
                                        Row(
                                            modifier = Modifier.fillMaxWidth().padding(top = 4.dp),
                                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                                        ) {
                                            FodderMetricChip("Green Clover", "${recommendation.greenCloverKg} Kg")
                                            FodderMetricChip("Khal/Wanda", "${recommendation.cottonseedKhalKg} Kg")
                                            FodderMetricChip("Bhoosa Straw", "${recommendation.dryStrawBhoosaKg} Kg")
                                        }
                                        Spacer(modifier = Modifier.height(8.dp))
                                        Text("📋 Veterinary Management Tips:", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary, fontSize = 10.sp)
                                        Text(recommendation.specialManagementTip, fontSize = 11.sp, lineHeight = 15.sp, color = Color.DarkGray)
                                        Text(recommendation.tipUrdu, fontSize = 11.sp, fontWeight = FontWeight.Medium, color = MaterialTheme.colorScheme.primary, lineHeight = 15.sp, modifier = Modifier.padding(top = 2.dp))
                                    }
                                }

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text("Vaccine Log Book / ویکسین ہسٹری", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                    Button(
                                        onClick = { showAddVaccineDialogState = animal.id },
                                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                                        shape = RoundedCornerShape(8.dp),
                                        modifier = Modifier.height(32.dp).testTag("btn_log_vaccine_${animal.id}")
                                    ) {
                                        Icon(Icons.Default.MedicalServices, contentDescription = null, modifier = Modifier.size(12.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("Log Vaccine", fontSize = 11.sp)
                                    }
                                }

                                Spacer(modifier = Modifier.height(8.dp))

                                if (animalVaccines.isEmpty()) {
                                    Text("This animal has no logged vaccinations. Recommend administering FMD or local livestock safety shots.", fontSize = 11.sp, color = Color.Gray)
                                } else {
                                    animalVaccines.forEach { record ->
                                        val scoreDate = SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date(record.dateAdministered))
                                        val dueDate = SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date(record.nextDueDate))

                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(vertical = 4.dp)
                                                .background(Color.Gray.copy(alpha = 0.03f), RoundedCornerShape(8.dp))
                                                .padding(6.dp),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Column {
                                                Text(record.vaccineName, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                                Text("By: ${record.administeredBy}", fontSize = 10.sp, color = Color.Gray)
                                            }
                                            Column(horizontalAlignment = Alignment.End) {
                                                Text("Given: $scoreDate", fontSize = 10.sp, color = Color.DarkGray)
                                                Text("Booster: $dueDate", fontSize = 10.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.primary)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Register Animal Dialog
    if (showAddAnimalDialog) {
        var name by remember { mutableStateOf("") }
        var selectedType by remember { mutableStateOf("Cow") }
        var breed by remember { mutableStateOf("Sahiwal Cow") }
        var age by remember { mutableStateOf("") }
        var selectedDistrict by remember { mutableStateOf("Sahiwal") }

        val animalTypes = listOf("Cow", "Buffalo", "Sheep", "Goat", "Bull", "Fat-tailed Sheep")
        
        val breedOptionsMap = mapOf(
            "Cow" to listOf("Sahiwal Cow", "Cholistani", "Tharparkar", "Red Sindhi", "Dhanni", "Achai"),
            "Buffalo" to listOf("Nili-Ravi", "Kundi", "Azi Kheli"),
            "Sheep" to listOf("Kajli Sheep", "Balkhi Sheep", "Damani", "Buchi", "Cholistani Sheep"),
            "Goat" to listOf("Teddy Goat", "Beetal Goat", "Kamori", "Dera Din Panah", "Barbari"),
            "Bull" to listOf("Bhagnari Bull", "Dhanni Bull", "Sahiwal Bull", "Bramfah"),
            "Fat-tailed Sheep" to listOf("Dumba (Fat-tailed)")
        )

        Dialog(onDismissRequest = { showAddAnimalDialog = false }) {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(
                    modifier = Modifier.padding(20.dp).fillMaxWidth().animateContentSize(),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text("Register New Livestock", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    Spacer(modifier = Modifier.height(4.dp))

                    OutlinedTextField(
                        value = name,
                        onValueChange = { name = it },
                        label = { Text("Animal Tag Name (e.g. Sahiwal Gold)") },
                        modifier = Modifier.fillMaxWidth().testTag("add_name_input"),
                        singleLine = true
                    )

                    // Type dropdown
                    var typeDropdownExpanded by remember { mutableStateOf(false) }
                    Box(modifier = Modifier.fillMaxWidth()) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { typeDropdownExpanded = true }
                        ) {
                            OutlinedTextField(
                                value = selectedType,
                                onValueChange = {},
                                label = { Text("Animal Type") },
                                trailingIcon = { Icon(Icons.Default.ArrowDropDown, null) },
                                readOnly = true,
                                enabled = false,
                                colors = androidx.compose.material3.OutlinedTextFieldDefaults.colors(
                                    disabledTextColor = MaterialTheme.colorScheme.onSurface,
                                    disabledBorderColor = MaterialTheme.colorScheme.outline,
                                    disabledLeadingIconColor = MaterialTheme.colorScheme.primary,
                                    disabledTrailingIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                                    disabledLabelColor = MaterialTheme.colorScheme.onSurfaceVariant,
                                ),
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                        DropdownMenu(
                            expanded = typeDropdownExpanded,
                            onDismissRequest = { typeDropdownExpanded = false }
                        ) {
                            animalTypes.forEach { t ->
                                DropdownMenuItem(
                                    text = { Text(t) },
                                    onClick = {
                                        selectedType = t
                                        breed = breedOptionsMap[t]?.firstOrNull() ?: ""
                                        typeDropdownExpanded = false
                                    }
                                )
                            }
                        }
                    }

                    // Breed dynamic selection dropdown
                    var breedDropdownExpanded by remember { mutableStateOf(false) }
                    val currentBreeds = breedOptionsMap[selectedType] ?: listOf()
                    Box(modifier = Modifier.fillMaxWidth()) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { breedDropdownExpanded = true }
                        ) {
                            OutlinedTextField(
                                value = breed,
                                onValueChange = {},
                                label = { Text("Select Breed") },
                                trailingIcon = { Icon(Icons.Default.ArrowDropDown, null) },
                                readOnly = true,
                                enabled = false,
                                colors = androidx.compose.material3.OutlinedTextFieldDefaults.colors(
                                    disabledTextColor = MaterialTheme.colorScheme.onSurface,
                                    disabledBorderColor = MaterialTheme.colorScheme.outline,
                                    disabledLeadingIconColor = MaterialTheme.colorScheme.primary,
                                    disabledTrailingIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                                    disabledLabelColor = MaterialTheme.colorScheme.onSurfaceVariant,
                                ),
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                        DropdownMenu(
                            expanded = breedDropdownExpanded,
                            onDismissRequest = { breedDropdownExpanded = false }
                        ) {
                            val recommendedBreeds = WeatherRiskManager.getRecommendedBreedsForDistrict(selectedDistrict, selectedType)
                            currentBreeds.forEach { b ->
                                val isRec = recommendedBreeds.any { b.lowercase().contains(it.lowercase()) || it.lowercase().contains(b.lowercase()) }
                                DropdownMenuItem(
                                    text = {
                                        Row(
                                            modifier = Modifier.fillMaxWidth().padding(horizontal = 4.dp),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(b)
                                            if (isRec) {
                                                Box(
                                                    modifier = Modifier
                                                        .background(Color(0xFFE8F5E9), RoundedCornerShape(4.dp))
                                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                                ) {
                                                    Text("Area Pick ⭐", fontSize = 8.sp, color = Color(0xFF2E7D32), fontWeight = FontWeight.ExtraBold)
                                                }
                                            }
                                        }
                                    },
                                    onClick = {
                                        breed = b
                                        breedDropdownExpanded = false
                                    }
                                )
                            }
                        }
                    }

                    // Automatic preview dainties
                    val previewRec = LivestockViewModel.getRecommendationForBreed(breed)
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.35f)),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Text("⚡ Food Recommendation Preview:", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                            Text(previewRec.dailyFodderFormula, fontSize = 11.sp, color = Color.DarkGray, maxLines = 2, lineHeight = 14.sp)
                        }
                    }

                    OutlinedTextField(
                        value = age,
                        onValueChange = { age = it },
                        label = { Text("Age in Months") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth().testTag("add_age_input"),
                        singleLine = true
                    )

                    // District dropdown
                    var districtDropdownExpanded by remember { mutableStateOf(false) }
                    Box(modifier = Modifier.fillMaxWidth()) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { districtDropdownExpanded = true }
                        ) {
                            OutlinedTextField(
                                value = selectedDistrict,
                                onValueChange = {},
                                label = { Text("Farmed District") },
                                trailingIcon = { Icon(Icons.Default.ArrowDropDown, null) },
                                readOnly = true,
                                enabled = false,
                                colors = androidx.compose.material3.OutlinedTextFieldDefaults.colors(
                                    disabledTextColor = MaterialTheme.colorScheme.onSurface,
                                    disabledBorderColor = MaterialTheme.colorScheme.outline,
                                    disabledLeadingIconColor = MaterialTheme.colorScheme.primary,
                                    disabledTrailingIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                                    disabledLabelColor = MaterialTheme.colorScheme.onSurfaceVariant,
                                ),
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                        DropdownMenu(
                            expanded = districtDropdownExpanded,
                            onDismissRequest = { districtDropdownExpanded = false }
                        ) {
                            WeatherRiskManager.availableDistricts.forEach { d ->
                                DropdownMenuItem(
                                    text = { Text(d) },
                                    onClick = {
                                        selectedDistrict = d
                                        districtDropdownExpanded = false
                                    }
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        TextButton(onClick = { showAddAnimalDialog = false }) {
                            Text("Cancel")
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Button(
                            onClick = {
                                val ageVal = age.toIntOrNull() ?: 12
                                viewModel.registerAnimal(name, selectedType, breed, ageVal, selectedDistrict)
                                showAddAnimalDialog = false
                            },
                            modifier = Modifier.testTag("submit_register_button")
                        ) {
                            Text("Register")
                        }
                    }
                }
            }
        }
    }

    // Log Vaccine Dialog
    if (showAddVaccineDialogState != null) {
        val animalId = showAddVaccineDialogState!!
        var vaccineName by remember { mutableStateOf("Foot and Mouth Disease (FMD)") }
        var administeredBy by remember { mutableStateOf("Punjab Veterinary Dept") }

        val vaccinesOptions = listOf(
            "Foot and Mouth Disease (FMD)",
            "Peste des Petits Ruminants (PPR)",
            "Bluetongue (BT) Vaccine",
            "Anthrax Vaccine",
            "Haemorrhagic Septicaemia (HS)",
            "Black Quarter (BQ) Vaccine"
        )

        Dialog(onDismissRequest = { showAddVaccineDialogState = null }) {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(
                    modifier = Modifier.padding(20.dp).fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text("Log Veterinary Vaccine", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    Spacer(modifier = Modifier.height(4.dp))

                    // Vaccine name dropdown
                    var vaccineDropdownExpanded by remember { mutableStateOf(false) }
                    Box(modifier = Modifier.fillMaxWidth()) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { vaccineDropdownExpanded = true }
                        ) {
                            OutlinedTextField(
                                value = vaccineName,
                                onValueChange = {},
                                label = { Text("Select Vaccine Type") },
                                trailingIcon = { Icon(Icons.Default.ArrowDropDown, null) },
                                readOnly = true,
                                enabled = false,
                                colors = androidx.compose.material3.OutlinedTextFieldDefaults.colors(
                                    disabledTextColor = MaterialTheme.colorScheme.onSurface,
                                    disabledBorderColor = MaterialTheme.colorScheme.outline,
                                    disabledLeadingIconColor = MaterialTheme.colorScheme.primary,
                                    disabledTrailingIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                                    disabledLabelColor = MaterialTheme.colorScheme.onSurfaceVariant,
                                ),
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                        DropdownMenu(
                            expanded = vaccineDropdownExpanded,
                            onDismissRequest = { vaccineDropdownExpanded = false }
                        ) {
                            vaccinesOptions.forEach { v ->
                                DropdownMenuItem(
                                    text = { Text(v) },
                                    onClick = {
                                        vaccineName = v
                                        vaccineDropdownExpanded = false
                                    }
                                )
                            }
                        }
                    }

                    OutlinedTextField(
                        value = administeredBy,
                        onValueChange = { administeredBy = it },
                        label = { Text("Administered Doctor/Dept") },
                        modifier = Modifier.fillMaxWidth().testTag("add_administered_by"),
                        singleLine = true
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        TextButton(onClick = { showAddVaccineDialogState = null }) {
                            Text("Cancel")
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Button(
                            onClick = {
                                viewModel.addVaccineRecord(
                                    animalId = animalId,
                                    vaccineName = vaccineName,
                                    dateAdministered = System.currentTimeMillis(),
                                    administeredBy = administeredBy
                                )
                                showAddVaccineDialogState = null
                            },
                            modifier = Modifier.testTag("submit_vaccine_button")
                        ) {
                            Text("Record Dose")
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun FodderMetricChip(label: String, value: String) {
    Box(
        modifier = Modifier
            .background(MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
            .border(0.5.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.2f), RoundedCornerShape(8.dp))
            .padding(horizontal = 8.dp, vertical = 4.dp)
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(label, fontSize = 9.sp, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold)
            Text(value, fontSize = 11.sp, color = MaterialTheme.colorScheme.onPrimaryContainer, fontWeight = FontWeight.Bold)
        }
    }
}

// ==================== GEMINI CHAT SCREEN & HELPER COMPOSABLES ====================

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun GeminiChatScreen(viewModel: LivestockViewModel) {
    val chatMessages by viewModel.chatMessages.collectAsState()
    val isChatLoading by viewModel.isChatLoading.collectAsState()
    val chatError by viewModel.chatError.collectAsState()
    
    var inputText by remember { mutableStateOf("") }
    val listState = androidx.compose.foundation.lazy.rememberLazyListState()

    // Auto-scroll to bottom of conversation
    LaunchedEffect(chatMessages.size) {
        if (chatMessages.isNotEmpty()) {
            listState.animateScrollToItem(chatMessages.size - 1)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .testTag("gemini_chat_screen")
    ) {
        // Chat Header
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.35f))
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .background(MaterialTheme.colorScheme.primary, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.AutoAwesome,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = "Gemini Support AI",
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(6.dp)
                                    .background(Color(0xFF4CAF50), CircleShape)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "Bilingual advisory on-demand",
                                fontSize = 11.sp,
                                color = Color.Gray
                            )
                        }
                    }
                }
                
                IconButton(
                    onClick = { viewModel.clearChat() },
                    modifier = Modifier.testTag("chat_clear_btn")
                ) {
                    Icon(
                        imageVector = Icons.Default.DeleteSweep,
                        contentDescription = "Clear Chat",
                        tint = MaterialTheme.colorScheme.error.copy(alpha = 0.8f)
                    )
                }
            }
        }

        // Messages List / Empty State
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(horizontal = 8.dp)
        ) {
            if (chatMessages.isEmpty()) {
                // Empty state or quick starting chips
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Forum,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.2f),
                        modifier = Modifier.size(72.dp)
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = "Consult Pakistan's Smartest Vet AI\nصلاحیت کار ماہر لائیو سٹاک مشیر",
                        textAlign = TextAlign.Center,
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Tap on any quick prompt below or write your own to consult nutrition, weather stresses, and disease management.",
                        textAlign = TextAlign.Center,
                        fontSize = 12.sp,
                        color = Color.Gray,
                        modifier = Modifier.padding(horizontal = 16.dp)
                    )
                    Spacer(modifier = Modifier.height(24.dp))
                    
                    val quickPrompts = listOf(
                        "🌾 Sahiwal cattle feed formulation.",
                        "🩺 Early signs of Bluetongue Virus.",
                        "🌡️ Managing herd THI heat stress.",
                        "💧 Goat water needs in winter."
                    )
                    
                    FlowRow(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.Center,
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        maxItemsInEachRow = 2
                    ) {
                        quickPrompts.forEach { qp ->
                            Card(
                                onClick = { viewModel.sendChatMessage(qp) },
                                shape = RoundedCornerShape(20.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                                modifier = Modifier
                                    .padding(4.dp)
                                    .testTag("quick_prompt_${qp.hashCode()}"),
                                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.15f))
                            ) {
                                Text(
                                    text = qp,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Medium,
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                        }
                    }
                }
            } else {
                androidx.compose.foundation.lazy.LazyColumn(
                    state = listState,
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(chatMessages) { message ->
                        ChatBubble(message)
                    }
                    if (isChatLoading) {
                        item {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                horizontalArrangement = Arrangement.Start,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(32.dp)
                                        .background(MaterialTheme.colorScheme.primaryContainer, CircleShape),
                                    contentAlignment = Alignment.Center
                                ) {
                                    CircularProgressIndicator(
                                        modifier = Modifier.size(16.dp),
                                        strokeWidth = 2.dp,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                }
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "Gemini is replying... (جواب آرہا ہے)",
                                    fontSize = 11.sp,
                                    color = Color.Gray
                                )
                            }
                        }
                    }
                }
            }
        }

        if (chatError != null) {
            Text(
                text = chatError!!,
                color = MaterialTheme.colorScheme.error,
                fontSize = 11.sp,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp),
                fontWeight = FontWeight.Bold
            )
        }

        // Message Input Row
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp),
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.12f))
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                TextField(
                    value = inputText,
                    onValueChange = { inputText = it },
                    placeholder = { Text("Ask Gemini about your herd... (سوال پوچھیں)", fontSize = 13.sp) },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("chat_input_field"),
                    colors = TextFieldDefaults.colors(
                        focusedContainerColor = Color.Transparent,
                        unfocusedContainerColor = Color.Transparent,
                        disabledContainerColor = Color.Transparent,
                        focusedIndicatorColor = Color.Transparent,
                        unfocusedIndicatorColor = Color.Transparent
                    ),
                    singleLine = true
                )
                
                IconButton(
                    onClick = {
                        if (inputText.isNotBlank()) {
                            viewModel.sendChatMessage(inputText)
                            inputText = ""
                        }
                    },
                    enabled = inputText.isNotBlank() && !isChatLoading,
                    modifier = Modifier
                        .background(
                            if (inputText.isNotBlank() && !isChatLoading) MaterialTheme.colorScheme.primary else Color.LightGray.copy(alpha = 0.5f),
                            CircleShape
                        )
                        .size(40.dp)
                        .testTag("chat_send_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Send,
                        contentDescription = "Send",
                        tint = if (inputText.isNotBlank() && !isChatLoading) Color.White else Color.Gray,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun ChatBubble(message: ChatMessage) {
    val isUser = message.sender == MessageSender.USER
    val alignment = if (isUser) Alignment.End else Alignment.Start
    val bgColors = if (isUser) {
        MaterialTheme.colorScheme.primary
    } else {
        MaterialTheme.colorScheme.surfaceVariant
    }
    val textColor = if (isUser) {
        MaterialTheme.colorScheme.onPrimary
    } else {
        MaterialTheme.colorScheme.onSurfaceVariant
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalAlignment = alignment
    ) {
        Row(
            verticalAlignment = Alignment.Bottom,
            horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start,
            modifier = Modifier.fillMaxWidth(0.9f)
        ) {
            if (!isUser) {
                Box(
                    modifier = Modifier
                        .size(30.dp)
                        .background(MaterialTheme.colorScheme.secondary.copy(alpha = 0.15f), CircleShape)
                        .padding(4.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.AutoAwesome,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(16.dp)
                    )
                }
                Spacer(modifier = Modifier.width(6.dp))
            }

            Surface(
                color = bgColors,
                shape = RoundedCornerShape(
                    topStart = 16.dp,
                    topEnd = 16.dp,
                    bottomStart = if (isUser) 16.dp else 4.dp,
                    bottomEnd = if (isUser) 4.dp else 16.dp
                ),
                shadowElevation = 1.dp,
                modifier = Modifier.testTag("chat_bubble_${message.id}")
            ) {
                Column(modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp)) {
                    MarkdownText(
                        text = message.text,
                        color = textColor,
                        fontSize = 13.sp
                    )
                }
            }
        }
    }
}

@Composable
fun MarkdownText(text: String, color: Color = Color.Unspecified, fontSize: TextUnit = TextUnit.Unspecified) {
    val lines = text.trimIndent().split("\n")
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        lines.forEach { line ->
            val trimmedLine = line.trim()
            when {
                trimmedLine.startsWith("###") -> {
                    Text(
                        text = trimmedLine.removePrefix("###").trim(),
                        fontSize = 15.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(top = 8.dp, bottom = 4.dp)
                    )
                }
                trimmedLine.startsWith("##") -> {
                    Text(
                        text = trimmedLine.removePrefix("##").trim(),
                        fontSize = 17.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(top = 10.dp, bottom = 6.dp)
                    )
                }
                trimmedLine.startsWith("#") -> {
                    Text(
                        text = trimmedLine.removePrefix("#").trim(),
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Black,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(top = 12.dp, bottom = 8.dp)
                    )
                }
                trimmedLine.startsWith("*") || trimmedLine.startsWith("-") -> {
                    val bulletText = trimmedLine.drop(1).trim()
                    val annotatedString = androidx.compose.ui.text.buildAnnotatedString {
                        var currentIndex = 0
                        while (currentIndex < bulletText.length) {
                            val startBold = bulletText.indexOf("**", currentIndex)
                            if (startBold == -1) {
                                append(bulletText.substring(currentIndex))
                                break
                            }
                            append(bulletText.substring(currentIndex, startBold))
                            val endBold = bulletText.indexOf("**", startBold + 2)
                            if (endBold == -1) {
                                append(bulletText.substring(startBold))
                                break
                            }
                            withStyle(style = androidx.compose.ui.text.SpanStyle(fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)) {
                                append(bulletText.substring(startBold + 2, endBold))
                            }
                            currentIndex = endBold + 2
                        }
                    }

                    Row(
                        modifier = Modifier.padding(start = 8.dp, top = 2.dp),
                        verticalAlignment = Alignment.Top
                    ) {
                        Text("•", fontSize = fontSize, fontWeight = FontWeight.Black, color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(end = 6.dp))
                        Text(
                            text = annotatedString,
                            fontSize = fontSize,
                            lineHeight = 18.sp,
                            color = color
                        )
                    }
                }
                trimmedLine.startsWith("1.") || trimmedLine.startsWith("2.") || trimmedLine.startsWith("3.") || trimmedLine.startsWith("4.") || trimmedLine.startsWith("5.") -> {
                    val prefix = trimmedLine.takeWhile { it != ' ' }
                    val content = trimmedLine.drop(prefix.length).trim()
                    val annotatedString = androidx.compose.ui.text.buildAnnotatedString {
                        var currentIndex = 0
                        while (currentIndex < content.length) {
                            val startBold = content.indexOf("**", currentIndex)
                            if (startBold == -1) {
                                append(content.substring(currentIndex))
                                break
                            }
                            append(content.substring(currentIndex, startBold))
                            val endBold = content.indexOf("**", startBold + 2)
                            if (endBold == -1) {
                                append(content.substring(startBold))
                                break
                            }
                            withStyle(style = androidx.compose.ui.text.SpanStyle(fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)) {
                                append(content.substring(startBold + 2, endBold))
                            }
                            currentIndex = endBold + 2
                        }
                    }

                    Row(
                        modifier = Modifier.padding(start = 8.dp, top = 2.dp),
                        verticalAlignment = Alignment.Top
                    ) {
                        Text(prefix, fontSize = fontSize, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(end = 6.dp))
                        Text(
                            text = annotatedString,
                            fontSize = fontSize,
                            lineHeight = 18.sp,
                            color = color
                        )
                    }
                }
                else -> {
                    if (trimmedLine.isNotEmpty()) {
                        val annotatedString = androidx.compose.ui.text.buildAnnotatedString {
                            var currentIndex = 0
                            while (currentIndex < trimmedLine.length) {
                                val startBold = trimmedLine.indexOf("**", currentIndex)
                                if (startBold == -1) {
                                    append(trimmedLine.substring(currentIndex))
                                    break
                                }
                                append(trimmedLine.substring(currentIndex, startBold))
                                val endBold = trimmedLine.indexOf("**", startBold + 2)
                                if (endBold == -1) {
                                    append(trimmedLine.substring(startBold))
                                    break
                                }
                                withStyle(style = androidx.compose.ui.text.SpanStyle(fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)) {
                                    append(trimmedLine.substring(startBold + 2, endBold))
                                }
                                currentIndex = endBold + 2
                            }
                        }
                        Text(
                            text = annotatedString,
                            fontSize = fontSize,
                            lineHeight = 18.sp,
                            color = color
                        )
                    }
                }
            }
        }
    }
}

