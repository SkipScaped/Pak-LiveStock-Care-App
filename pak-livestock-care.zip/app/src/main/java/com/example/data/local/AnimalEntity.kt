package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "animals")
data class AnimalEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String,
    val type: String, // Sheep, Cow, Buffalo, Bull, Goat, Fat-tailed Sheep
    val breed: String, // Nili-Ravi, Sahiwal, Kajli, Teddy, Balkhi, Kundi, etc.
    val ageInMonths: Int,
    val district: String, // Multan, Sahiwal, Sargodha, Faisalabad, etc.
    val registrationDate: Long = System.currentTimeMillis()
)
