package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface LivestockDao {
    // --- Animal Queries ---
    @Query("SELECT * FROM animals ORDER BY id DESC")
    fun getAllAnimals(): Flow<List<AnimalEntity>>

    @Query("SELECT * FROM animals WHERE id = :id")
    suspend fun getAnimalById(id: Int): AnimalEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAnimal(animal: AnimalEntity): Long

    @Query("DELETE FROM animals WHERE id = :id")
    suspend fun deleteAnimalById(id: Int)

    // --- Vaccine Queries ---
    @Query("SELECT * FROM vaccine_records WHERE animalId = :animalId ORDER BY dateAdministered DESC")
    fun getVaccinesForAnimal(animalId: Int): Flow<List<VaccineRecordEntity>>

    @Query("SELECT * FROM vaccine_records ORDER BY dateAdministered DESC")
    fun getAllVaccineRecords(): Flow<List<VaccineRecordEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertVaccineRecord(record: VaccineRecordEntity)

    @Query("DELETE FROM vaccine_records WHERE id = :id")
    suspend fun deleteVaccineRecordById(id: Int)
}
