package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(entities = [AnimalEntity::class, VaccineRecordEntity::class], version = 1, exportSchema = false)
abstract class LivestockDatabase : RoomDatabase() {
    abstract fun livestockDao(): LivestockDao

    companion object {
        @Volatile
        private var INSTANCE: LivestockDatabase? = null

        fun getDatabase(context: Context): LivestockDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    LivestockDatabase::class.java,
                    "pak_livestock_db"
                )
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
