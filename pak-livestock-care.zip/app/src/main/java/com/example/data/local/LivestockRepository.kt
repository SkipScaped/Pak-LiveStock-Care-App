package com.example.data.local

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.onStart
import java.util.Calendar

class LivestockRepository(private val dao: LivestockDao) {
    val allAnimals: Flow<List<AnimalEntity>> = dao.getAllAnimals().onStart {
        prepopulateIfEmpty()
    }

    val allVaccineRecords: Flow<List<VaccineRecordEntity>> = dao.getAllVaccineRecords()

    fun getVaccinesForAnimal(animalId: Int): Flow<List<VaccineRecordEntity>> =
        dao.getVaccinesForAnimal(animalId)

    suspend fun getAnimalById(id: Int): AnimalEntity? = dao.getAnimalById(id)

    suspend fun insertAnimal(animal: AnimalEntity): Long = dao.insertAnimal(animal)

    suspend fun deleteAnimalById(id: Int) = dao.deleteAnimalById(id)

    suspend fun insertVaccineRecord(record: VaccineRecordEntity) =
        dao.insertVaccineRecord(record)

    suspend fun deleteVaccineRecordById(id: Int) = dao.deleteVaccineRecordById(id)

    private suspend fun prepopulateIfEmpty() {
        val currentList = dao.getAllAnimals().first()
        if (currentList.isEmpty()) {
            val cal = Calendar.getInstance()
            
            // 1. Sahiwal Breed Cow (Farmed in Multan, Punjab)
            val cowId = dao.insertAnimal(
                AnimalEntity(
                    name = "Sahiwal Gold",
                    type = "Cow",
                    breed = "Sahiwal (Milk-line)",
                    ageInMonths = 32,
                    district = "Multan"
                )
            )
            cal.add(Calendar.MONTH, -6)
            dao.insertVaccineRecord(
                VaccineRecordEntity(
                    animalId = cowId.toInt(),
                    vaccineName = "Foot & Mouth Disease (FMD)",
                    dateAdministered = cal.timeInMillis,
                    nextDueDate = cal.apply { add(Calendar.MONTH, 6) }.timeInMillis,
                    status = "Administered",
                    administeredBy = "Punjab Vet Dept (Multan)"
                )
            )

            // 2. Nili-Ravi Buffalo (Farmed in Okara/Sahiwal, Punjab)
            val buffaloId = dao.insertAnimal(
                AnimalEntity(
                    name = "Malka-e-Ravi",
                    type = "Buffalo",
                    breed = "Nili-Ravi (Cholan-grade)",
                    ageInMonths = 45,
                    district = "Sahiwal"
                )
            )
            cal.add(Calendar.MONTH, -2)
            dao.insertVaccineRecord(
                VaccineRecordEntity(
                    animalId = buffaloId.toInt(),
                    vaccineName = "Hemorrhagic Septicemia (HS)",
                    dateAdministered = cal.timeInMillis,
                    nextDueDate = cal.apply { add(Calendar.MONTH, 3) }.timeInMillis,
                    status = "Administered",
                    administeredBy = "Dr. Shakoor (Sahiwal)"
                )
            )

            // 3. Kajli Sheep (Farmed in Sargodha, Punjab)
            val sheepId = dao.insertAnimal(
                AnimalEntity(
                    name = "Kajli Prince",
                    type = "Sheep",
                    breed = "Kajli (Elegant)",
                    ageInMonths = 18,
                    district = "Sargodha"
                )
            )
            cal.add(Calendar.MONTH, -4)
            dao.insertVaccineRecord(
                VaccineRecordEntity(
                    animalId = sheepId.toInt(),
                    vaccineName = "PPR Sheep Vaccine",
                    dateAdministered = cal.timeInMillis,
                    nextDueDate = cal.apply { add(Calendar.MONTH, 12) }.timeInMillis,
                    status = "Administered",
                    administeredBy = "Sargodha Rural Extension"
                )
            )

            // 4. Beetal Goat (Farmed in Faisalabad, Punjab)
            val goatId = dao.insertAnimal(
                AnimalEntity(
                    name = "Beetal Queen",
                    type = "Goat",
                    breed = "Beetal (Amritsari line)",
                    ageInMonths = 22,
                    district = "Faisalabad"
                )
            )
            cal.add(Calendar.MONTH, -5)
            dao.insertVaccineRecord(
                VaccineRecordEntity(
                    animalId = goatId.toInt(),
                    vaccineName = "Enterotoxemia (ET)",
                    dateAdministered = cal.timeInMillis,
                    nextDueDate = cal.apply { add(Calendar.MONTH, 6) }.timeInMillis,
                    status = "Administered",
                    administeredBy = "Faisalabad Vet Univ Clinic"
                )
            )

            // 5. Fat-tailed Sheep (Dumba) (Farmed in Quetta/Peshawar)
            val dumbaId = dao.insertAnimal(
                AnimalEntity(
                    name = "Balkhi Dumba",
                    type = "Fat-tailed Sheep",
                    breed = "Balkhi Grade-A",
                    ageInMonths = 14,
                    district = "Quetta"
                )
            )
            cal.add(Calendar.MONTH, -1)
            dao.insertVaccineRecord(
                VaccineRecordEntity(
                    animalId = dumbaId.toInt(),
                    vaccineName = "Bluetongue Attenuated Vaccine",
                    dateAdministered = cal.timeInMillis,
                    nextDueDate = cal.apply { add(Calendar.MONTH, 11) }.timeInMillis,
                    status = "Administered",
                    administeredBy = "Quetta Livestock Center"
                )
            )

            // 6. Sibi Bhagnari Bull (Farmed in Sibi, Balochistan)
            val bullId = dao.insertAnimal(
                AnimalEntity(
                    name = "Sibi King",
                    type = "Bull",
                    breed = "Bhagnari (Heavyweight)",
                    ageInMonths = 36,
                    district = "Sibi"
                )
            )
            cal.add(Calendar.MONTH, -3)
            dao.insertVaccineRecord(
                VaccineRecordEntity(
                    animalId = bullId.toInt(),
                    vaccineName = "Black Quarter (BQ) Vaccine",
                    dateAdministered = cal.timeInMillis,
                    nextDueDate = cal.apply { add(Calendar.MONTH, 9) }.timeInMillis,
                    status = "Administered",
                    administeredBy = "Sibi Fair Veterinary Base"
                )
            )
        }
    }
}
