package com.example.data.local

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "vaccine_records",
    foreignKeys = [
        ForeignKey(
            entity = AnimalEntity::class,
            parentColumns = ["id"],
            childColumns = ["animalId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index(value = ["animalId"])]
)
data class VaccineRecordEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val animalId: Int,
    val vaccineName: String, // FMD, Anthrax, PPR, Black Quarter, HS, etc.
    val dateAdministered: Long,
    val nextDueDate: Long,
    val status: String, // Administered, Scheduled, Overdue
    val administeredBy: String = "Veterinary Clinic"
)
