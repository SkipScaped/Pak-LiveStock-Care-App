package com.example.data.weather

import com.squareup.moshi.JsonClass
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.GET
import retrofit2.http.Query
import java.util.concurrent.TimeUnit
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory

@JsonClass(generateAdapter = true)
data class OpenWeatherResponse(
    val name: String?,
    val main: MainTemp?,
    val wind: WindInfo?,
    val weather: List<WeatherDescription>?
)

@JsonClass(generateAdapter = true)
data class MainTemp(
    val temp: Float?,
    val humidity: Float?
)

@JsonClass(generateAdapter = true)
data class WindInfo(
    val speed: Float?
)

@JsonClass(generateAdapter = true)
data class WeatherDescription(
    val main: String?,
    val description: String?
)

interface OpenWeatherApiService {
    @GET("data/2.5/weather")
    suspend fun getWeather(
        @Query("q") query: String,
        @Query("appid") apiKey: String,
        @Query("units") units: String = "metric"
    ): OpenWeatherResponse
}

object WeatherClient {
    private const val BASE_URL = "https://api.openweathermap.org/"

    private val moshi = Moshi.Builder()
        .addLast(KotlinJsonAdapterFactory())
        .build()

    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .build()

    val service: OpenWeatherApiService by lazy {
        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .client(okHttpClient)
            .addConverterFactory(MoshiConverterFactory.create(moshi))
            .build()
            .create(OpenWeatherApiService::class.java)
    }
}
