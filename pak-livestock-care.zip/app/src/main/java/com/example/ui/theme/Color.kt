package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Light Colors (Pastoral Fields theme)
val GrassGreenPrimary = Color(0xFF1B5E20)       // Deep beautiful green representing green pastures
val SageGreenSecondary = Color(0xFF4CAF50)     // Bright fresh grass color
val WarmSoilTertiary = Color(0xFF8D6E63)       // Earth tone for livestock animal associations

// Neutral Colors
val OffWhiteBackground = Color(0xFFF9FBE7)     // Warm bright background
val SlateText = Color(0xFF1E231E)              // Near-black dark olive
val LightSurface = Color(0xFFF1F8E9)           // Light green surface shading
val AccentAmber = Color(0xFFFFB300)            // Highlighting warnings & Bluetongue danger levels

// Dark Colors (Cosmic Fields theme)
val DarkGreenSurface = Color(0xFF1B2E1E)       // Dark green for night mode
val DeepFieldBackground = Color(0xFF0F1B11)    // Deep night black-green
val DarkTextPrimary = Color(0xFFE8F5E9)        // Crisp light green-tinted text
val DarkPrimary = Color(0xFF81C784)            // Healing green
val DarkSecondary = Color(0xFFA5D6A7)          // Light sage secondary
val DarkTertiary = Color(0xFFD7CCC8)           // Light clay
